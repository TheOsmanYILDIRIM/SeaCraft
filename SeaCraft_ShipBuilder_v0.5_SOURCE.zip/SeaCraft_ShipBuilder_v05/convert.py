from PIL import Image, ImageDraw
from pathlib import Path
c=Image.new('RGB',(1500,1000),'#30343b');d=ImageDraw.Draw(c)
for i,p in enumerate(sorted(Path('outputs').glob('SC-*'))):
 for file in p.glob('*.rgba'):
  sz=512 if file.stem=='preview' else 2048
  im=Image.frombytes('RGBA',(sz,sz),file.read_bytes());im.save(file.with_suffix('.png'));file.unlink()
 im=Image.open(p/'preview.png');im.thumbnail((280,300));x=(i%5)*300;y=i//5*333;c.paste(im,(x+(300-im.width)//2,y+20),im);d.text((x+10,y+7),p.name,fill='white')
c.save('fleet_preview.jpg',quality=93)
