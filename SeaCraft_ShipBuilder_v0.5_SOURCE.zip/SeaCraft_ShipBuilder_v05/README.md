# SeaCraft · parametrik gemi referans oluşturucu v0.3

Amaç: GPT Image için gerçek 3D geometriden gemiye özel, renkli ve renksiz CD referansları üretmek. Oyuna doğrudan konulacak 3D model, nihai sanat veya fizik simülasyonu değildir.

## Kullanım
`offline.html` dosyasını tarayıcıda açın. İnternet bağlantısı gerekmez. SC-01–SC-15 reçetelerinden seçin, gövde, donanım, direk/arma konumu ve ölçeğini değiştirin. Her arma için sabit/kontrol/bağlama halatları ve donanım açılıp kapanabilir; silinmez. Baş yelkeninin havada görünmemesi için taşıyıcı ıstralya varsayılan olarak açık, diğer halatlar kapalıdır. Halatları kapat düğmesi taşıyıcı ıstralyayı da kapatır. 5 yön CD varsayılan; SC-15 için asimetri nedeniyle 8 bağımsız yön. Renkli ve renksiz 2048² panolar aynı geometriyi, kamerayı, ölçeği ve yerleşimi kullanır. JSON kaydedilebilir ve tekrar yüklenebilir. Tam GLB gizli geometriyi de korur; görünürlük tercihinin genel GLB görüntüleyicilerince uygulanması garanti değildir. Referans GLB yalnız görünür geometriyi içerir.

## Kaynaklar
- Kanonik gemi fişleri, doğrulanmış önceki snapshot: https://github.com/TheOsmanYILDIRIM/SeaCraft/blob/17e4eb1a382dde19ef9e4777452751ad795c7712/GEMI_GORSEL_TASARIM_VE_SPRITE_PLANI.md
- `engine.mjs`, `rigs.mjs`: önceki Arma Editörü 21 paketinden aynen alınmıştır.
- `ship.mjs`: tek parametrik kesit-loft gövde motoru, 6 pruva, 6 kıç profili, üst yapılar, oyuk top portları, 16 donanım türü, arma montaj adaptörü.
- `presets.mjs`: 15 gemi için **taslak** reçete; bağımsız gemi meshleri elle üretilmedi. Belirtilmeyen boylar ve konumlar tasarım varsayımıdır.
- `render.mjs`: gerçek Three.js r180 geometrisini world-space dönüştüren CPU z-buffer rasterizer. WebGL gerekli değildir. Beş görünüş için ortak ölçekli CD yerleşimini arar; sekiz görünüş halka düzenine yerleştirilir.
- `outputs/SC-*/`: her gemi için `ship.glb`, `preset.json`, `clay.png`, `colored.png`, `preview.png`.
- `verification.json`, `viewer_report.json`: yerel test kanıtı.
- `lib/package/LICENSE`: Three.js MIT lisansı.

## Yeniden üretim
Node.js 22 + Python (Pillow, numpy) kullanıldı. Bağımlılık pakete dahil; npm ağ bağlantısı gerekmez.
```
mkdir -p node_modules
ln -s ../lib/package node_modules/three
node generate.mjs
python convert.py
python bundle.py
```
Tarayıcı testi için Playwright + Chromium: `python test_viewer.py`. `viewer.html` kaynak modülleri kullanır, `offline.html` bağımsız dosyadır.

## Doğrulanmış sınırlar
- GLTFExporter/GLTFLoader ile 15/15 GLB geri okuma; toplam 30 CD PNG ve 156 ayrı görünüş. Kanonik direk/bez adetleri ve top portu adetleri eşleşti. Renkli/renksiz alfa maskeleri ve yerleşim aynı; v0.3 tarihsel slot aralığı 33 px; v0.4 güncel silüet aralığı ayrı rapordadır.
- Mobil genişlikte Chromium ile 15 reçete, halat görünürlüğü, pruva seçimi, direk ekleme, reset, JSON kaydet/aç, PNG/GLB download test edildi. Gerçek Android cihaz ve GPT Image çıktısı test edilmedi.
- 3D modeller kasıtlı olarak renksiz ve basit yapısaldır; materyal/texture, dekorasyon ve yaşlandırma üretim dışında. Özellikle SC-15'in asimetrik hasarı şimdilik eksik küpeşte ve kaburga göstergeleriyle temsil edilir; gerçek çökmüş kıç geometrisi tamamlanmadı. H/S durumları ayrıca çalışılmalı. SC-07 üçgen boyuna arma seçimi öneridir. Her gemide özel halat ankrajlarının gerçek güverteye fiziksel uyumu, arma/gövde arası tüm çakışmalar ve gemi oranlarının birebir sanat onayı henüz tamamlanmadı. Bu nedenle reçeteler başlangıç tasarımlarıdır; editörden ayarlanabilir. Pruva/kıç profilleri geometrik kılavuz, gerçek tarihî gemilerin mühendislik planları değildir.
- GitHub'a yazma yapılmadı. Kanonik tasarım dosyası ve onaylı 2D sprite'lar değişmedi.

## v0.2 — Bağımsız top portu sistemi
- `ports.mjs`: 4 açıklık şekli (klasik kareye yakın, pahlı, yuvarlak, stilize kemerli); gerçek loft kesimi, yüzeye uyumlu çerçeve, gömme eşik/oyuk ve ayrı üst menteşeli kapak. Kemerli dekoratif seçenek tarihsel standart değildir. Tarihsel kaynak: https://www.royalnavymuseums.org.uk/hms-victory-conservation-log ve https://www.rmg.co.uk/collections/objects/rmgc-object-68355 .
- 4 sıra, sıra başına 1–16 port/borda; aralık veya başlangıç/bitiş, dikey seviye, boyut, çerçeve, derinlik, kapak açısı, borda seçimi. Tekil port konumu, boyutu, şekli, kapağı ve etkinliği değişebilir. Sıra kapatılırsa gövde yüzeyi yeniden kapanır; JSON ayarı korunur. Port eni ve boyu gövde eninin oranıdır; v0.1'deki yükseklik oranının yorumu değiştiğinden eski özel reçetelerde görsel kontrol önerilir. Çakışma halinde açıklık boyutu küçülür, üst üste merkezler reddedilir. Asimetrik port düzeninde HTML otomatik 8 bağımsız yön kullanır. SC-15'in iskeledeki iki kapalı portu fişe göre uygulandı.
- Kontroller: `node test_ports.mjs` (36 pruva/kıç kombinasyonu, 4 şekil GLB dönüşü, düzenleme); `node check_openings.mjs` (40 gerçek açıklık ışın testi); `python test_port_viewer.py` (mobil viewport). CPU rasterizer kullanıldı; fiziksel gemi yapım ölçüleri veya gerçek Android cihaz testi değildir. Oyuklar iç batarya hacmi değil, referans için kapalı derinlik yüzeyidir. Mevcut arma motoru değişmedi.

## v0.3 — Modüler gövde dekorasyonları
- `decor.mjs` 18 bağımsız prosedürel Three.js dekor modeli sağlar. Mevcut 15 gemi reçetesi, 21 arma ve port sistemi değiştirilmeden korunur; eski JSON dosyalarında decorations boş listeye tamamlanır.
- Montaj: iki borda (yansıtılmış), tek borda, pruva, kıç veya güverte. Borda ankrajı gerçek parametrik yüzey noktasını ve yerel normali izler. Boyuna ve dikey konum, enine konum, genel ölçek, üç ayrı boyut çarpanı, yüzey uzaklığı, dikey kaydırma, dönüş ve eğim; tekrar adedi/aralığı; ahşap/demir/bronz/kemik tonları; gizleme ve çoğaltma kontrolleri.
- Tam GLB tüm modelleri içerir; görünür GLB ve PNG gizli dekorları dışarıda bırakır. Tek taraflı veya merkez montajlarda güvenli tarafta kalmak için 8 yön seçilir. Referans renkleri tanısaldır, final sanat paleti değildir.
- Portlarla yaklaşık örtüşme uyarısı ve boyuna tekrar sınırlandırma uyarısı vardır; dekorun diğer donanımlarla çarpışması otomatik çözülmez. Uç yüzeyleri ve borda montajları yaklaşık ankrajdır; geniş rijit dekor parçaları eğri gövdeye deforme edilmez, offset/eğim ile ayarlanır. Pruva/kıç montajında boyuna konum değil, enine konum ve dikey seviye kullanılır. Dekoratif pencere gerçek gövde açıklığı açmaz.
- `decoration_catalog.png` 18 modelin gerçek renderı. `decor_samples/SC04_example.json` düzenlenebilir örnek, `SC04_example.glb` ve `ship_*.png` onun önizlemeleri. `outputs/` önceki dekorasyonsuz filo referanslarını aynen korur.
- `node test_decor.mjs && python decor_preview.py && python bundle.py` ile örnekler tekrar üretilebilir; `python test_decor_viewer.py` tarayıcı testi. `decor_report.json` ve `decor_viewer_report.json` yeni doğrulama kanıtları. 18 tip, 15 gemide GLB geri okuma ve gizleme; 36 profil kombinasyonu, renkli/renksiz alfa eşliği, mobil genişlikte Chromium kontrolü ve eski port editörü regresyon testi geçti. Gerçek Android ve GPT Image üretimi test edilmedi. GitHub'a yazılmadı.

## v0.4 — Sıkı beş yön CD
- Beş yön için gerçek projeksiyon noktalarının dışbükey zarfından muhafazakâr satır aralıkları çıkarılır; dikdörtgen sınırları yerine genişletilmiş silüetlerin ayrımı çözülür. Ortak ölçek, sabit 55° kamera, yönler ve kare format korunur. 512 birimlik ortak yerleşim koordinatları HTML ve 2048 PNG için aynı; piksel yuvarlama farkı normaldir.
- 14 simetrik reçetede alfa doluluğu v0.3'e göre %17,4–59,1 arttı (ortalama %35,4). 2048 PNG üzerinde altı piksel Chebyshev açıklığı ve kenar payı, alfa eşliği, HTML/PNG normalize yerleşim eşliği doğrulandı. SC-15 ve diğer asimetrik sekiz yön düzeni değiştirilmedi. Algoritma en iyi bulunan güvenli yerleşimi seçer; küresel optimum garantisi yoktur.
- `check_cd_tight.mjs`, `check_cd_clearance.mjs`, `tight_cd_report.json`, `tight_clearance_report.json` test/kanıt; `CD_before_after.png` karşılaştırma. Tarayıcıda önceki arma, port, dekor ve dışa aktarım testleri yeniden geçti. Gerçek Android testi yok.

## v0.5 — Mobil editör performansı
- Geometri oluşturma, CD yerleşim ve CPU rasterizasyonu ayrı Web Worker'da. Çevrimdışı HTML içindeki tek parça klasik worker bundle, yerel/null-origin dosya görüntüleyicilerinde iç içe modül worker kısıtını önler. Three.js r180 geometrileri ve final raster matematiği korunur.
- Kamera sürüklemede 280 px, ayar değişiminde 320 px önizleme; durunca 640 px tek yön / 760 px CD. CD'nin pahalı yerleşim hesabı kısa duraklamadan sonra yapılır. En fazla bir aktif ve bir güncel bekleyen önizleme; eskimiş kareler atlanır. Aynı modelde dünya koordinatları önbelleğe alınır. PNG 2048 px tam kalite ve aynı yerleşim; GLB ve JSON işlevleri korunur. Worker engellendiğinde daha düşük çözünürlüklü CPU uyumluluk modu vardır; bu mod aynı akıcılığı garanti etmez.
- `test_performance.py`: Chromium 430×900 mobil viewport, 4× CPU yavaşlatma, SC-08 kamera sürükleme. İşleyici medyanı 340,9 ms → 0,1 ms; en uzun zamanlayıcı aralığı 512,4 → 26,2 ms. Bu ölçümler giriş işleyicisi/ana iş parçacığı gecikmesidir, gerçek telefon FPS ölçümü değildir. SC-02 2048² renksiz PNG pikselleri v0.4 ile birebir eşit. `test_worker_interactions.py`: native Chromium touch, CD hesaplanırken görünüş değiştirme ve slider testi başarılı. Eski üç tarayıcı regresyon testi de geçti. Fiziksel Android cihaz testi yapılmadı; GitHub'a yazılmadı.
- Yeniden oluşturma: `python bundle.py`; hem `offline.html` hem `preview-worker.bundle.js` oluşturulur. `viewer.html` kaynak sürümü yerel HTTP sunucusundan çalıştırılır; bağımsız `offline.html` internet gerektirmez. Worker bundle kaynak modüllerinden üretilir.
