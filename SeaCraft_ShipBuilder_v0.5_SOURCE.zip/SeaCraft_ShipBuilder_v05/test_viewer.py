from pathlib import Path
from playwright.sync_api import sync_playwright
from PIL import Image
import json
r=Path(__file__).parent
with sync_playwright() as p:
 b=p.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox']);page=b.new_page(viewport={'width':430,'height':900},accept_downloads=True);errors=[];page.on('pageerror',lambda e:errors.append(str(e)));page.set_content((r/'offline.html').read_text());page.wait_for_function('window.ready===true',timeout=20000)
 state=lambda:page.evaluate('window.shipTest.state()');results={}
 for code in page.locator('#ship option').evaluate_all('(opts)=>opts.map(o=>o.value)'):
  page.select_option('#ship',code);a=state();assert a['preset']['id']==code;assert a['visible']>0;results[code]={'visible':a['visible'],'rigs':len(a['preset']['rigs'])};print(code,flush=True)
 page.select_option('#ship','SC-02');a=state();page.click('#full');page.wait_for_function('window.shipTest.state().visible>'+str(a['visible']));page.click('#clean');page.wait_for_function('window.shipTest.state().preset.support===false && window.shipTest.state().visible<'+str(a['visible']));page.click('#reset');assert state()['visible']==a['visible'];page.locator('#hull select').first.select_option('round');page.wait_for_function('window.shipTest.state().preset.bow==="round"');page.click('#addRig');page.wait_for_function('window.shipTest.state().preset.rigs.length===2');page.click('#reset');page.click('#cd');page.locator('#diag').check();page.screenshot(path=str(r/'editor_preview.png'),full_page=True)
 for key in ['clay','colored']:
  with page.expect_download(timeout=30000) as d:page.click('#'+key)
  im=Image.open(d.value.path()).convert('RGBA');assert im.size==(2048,2048);assert im.getchannel('A').getbbox();assert im.getpixel((0,0))[3]==0
 for key in ['glb','visibleGlb']:
  with page.expect_download(timeout=30000) as d:page.click('#'+key)
  assert Path(d.value.path()).read_bytes()[:4]==b'glTF'
 with page.expect_download() as d:page.click('#savePreset')
 saved=json.loads(Path(d.value.path()).read_text());assert saved['id']=='SC-02';page.select_option('#ship','SC-15');assert page.locator('#eight').is_checked();page.locator('#file').set_input_files(str(d.value.path()));page.wait_for_function('window.shipTest.state().preset.id==="SC-02"');assert not errors,errors;b.close()
(r/'viewer_report.json').write_text(json.dumps({'ships':results,'mobile_viewport':True,'toggle':True,'hull_edit':True,'add_rig':True,'png':True,'glb':True,'preset_roundtrip':True},indent=2))
