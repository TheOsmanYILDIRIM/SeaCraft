from PIL import Image,ImageDraw,ImageFont
from pathlib import Path
p=Path('decor_samples');font=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',20); labels={'shield':'Arma kalkanı','medallion':'Yuvarlak mühür','scroll':'Kıvrımlı oyma','strap':'Demir takviye','rivet':'Perçin plakası','window':'Kıç penceresi','gallery':'Kıç galerisi','lantern':'Kafesli fener','anchor':'Çıpa','chain':'Zincir','fender':'Usturmaça','cleat':'Koçboynuzu','bone':'Kemik kama','jaw':'Çene figürü','eye':'Örtülü göz','trim':'Oyma borda şeridi','rib':'Dış kaburga','crest':'Çatal arma'}
for f in p.glob('*.rgba'):
 n=2048 if f.stem in ['ship_clay','ship_color'] else 1024 if f.stem.startswith('ship_') else 360
 Image.frombytes('RGBA',(n,n),f.read_bytes()).save(f.with_suffix('.png'));f.unlink()
c=Image.new('RGB',(1500,1800),'#292e35');d=ImageDraw.Draw(c)
for i,(k,v) in enumerate(labels.items()):
 x=(i%3)*500;y=(i//3)*300;d.rounded_rectangle((x+8,y+8,x+492,y+292),radius=10,fill='#aeb6be');im=Image.open(p/(k+'.png'));im=im.crop(im.getbbox());im.thumbnail((410,231));c.paste(im,(x+(500-im.width)//2,y+12+(235-im.height)//2),im);d.text((x+250,y+266),v,anchor='mm',font=font,fill='#232932')
c.save('decoration_catalog.png')
