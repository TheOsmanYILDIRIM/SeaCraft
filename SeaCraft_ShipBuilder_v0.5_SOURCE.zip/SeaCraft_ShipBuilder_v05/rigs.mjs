// SeaCraft traditional rig library: X aft, Y up, Z starboard. Bow = -X.
// Normalized mast height H=1. Coordinates are design ratios, not historical measurements.
export const specs={
 'SQ-1':{ref:'126723.png',type:'Single square course',sails:['course']},
 'SQ-2':{ref:'126724.png',type:'Course + square topsail',sails:['course','topsail']},
 'GF-1':{ref:'126725.png',type:'Boomed gaff mainsail',sails:['gaff']},
 'JB-1':{ref:'126726.png',type:'Single hanked jib / headsail module',sails:['jib']},
 'GFJ-1':{ref:'126728.png',type:'Gaff sloop rig',sails:['gaff','jib']},
 'LT-1':{ref:'126774.png',type:'Triangular Mediterranean lateen',sails:['lateen']},
 'LG-1':{ref:'126799.png',type:'Loose-footed standing lug',sails:['lug']},
 'SQG-1':{ref:'126802.png',type:'Gaff mainsail + square topsail',sails:['gaff','topsail']},
 'SQ-3':{type:'Course, topsail, topgallant',sails:['course','topsail','topgallant']},
 'SQ-4':{type:'Course, topsail, topgallant, royal (optional)',sails:['course','topsail','topgallant','royal']},
 'GF-H':{type:'Short half gaff / spanker',sails:['gaff']},
 'LT-L':{type:'Low short lateen',sails:['lateen']},
 'JB-L':{type:'Low single headsail',sails:['jib']},
 'TR-1':{type:'Triangular fore-and-aft main with boom',sails:['triangle']},
 'TRJ-L':{type:'Triangular main + low jib, single mast',sails:['triangle','jib']},
 'JB-2':{type:'Inner staysail and outer jib',sails:['staysail','jib']},
 'SQG-H':{type:'Tall gaff + small square topsail',sails:['gaff','topsail']},
 'SQGJ-2':{type:'Topsail cutter: gaff, square topsail, two headsails',sails:['gaff','topsail','staysail','jib']},
 'SQ-D':{type:'Damaged square course',sails:['course']},
 'LT-D':{type:'Damaged lateen',sails:['lateen']},
 'MAST-D':{type:'Broken mast stump, no sail',sails:[]}
};
