import {createShip} from './ship.mjs';
import {renderSingle,renderCD} from './render.mjs';
let model,revision=-1;
function dispose(g){const mats=new Set();g?.traverse(o=>{if(o.isMesh){o.geometry.dispose();mats.add(o.material)}});mats.forEach(m=>m.dispose())}
function needsEight(p,m){const q=m.userData.portPlan||[];return p.asymmetric||m.userData.decorEight||q.some(a=>!q.some(b=>a.ri===b.ri&&a.i===b.i&&a.s===-b.s&&a.shape===b.shape&&a.lid===b.lid&&['t','v','dt','dv','angle'].every(k=>Math.abs((a[k]??0)-(b[k]??0))<1e-7)))}
self.onmessage=({data:q})=>{try{const t=performance.now();if(revision!==q.revision){const next=createShip(q.preset);dispose(model);model=next;model.userData.cachePreviewGeometry=true;revision=q.revision}const built=performance.now();const eight=q.eight||needsEight(q.preset,model);const im=q.cd?renderCD(model,q.size,q.diag,eight):renderSingle(model,q.size,q.az,q.el,q.diag);const info={ports:model.userData.portPlan,decor:model.userData.decorPlan,eight};self.postMessage({id:q.id,revision,im,info,buildMs:built-t,renderMs:performance.now()-built},[im.data.buffer]);}catch(e){self.postMessage({id:q.id,error:String(e.message||e)})}};
self.postMessage({ready:true});
