from pathlib import Path
from playwright.sync_api import sync_playwright
from PIL import Image,ImageChops
import json,io,base64,statistics
r=Path(__file__).parent
old=r.parent/'SeaCraft_ShipBuilder_v04'/'offline.html'
def bench(page,path):
 page.set_content(path.read_text());page.wait_for_function('window.ready===true');
 newer=page.evaluate('!!window.shipTest.perf');
 if newer:page.wait_for_function('window.shipTest.perf().completed>0');assert page.evaluate('window.shipTest.perf().backend')=='worker'
 # CPU throttling for constrained desktop comparison (not physical Android).
 client=page.context.new_cdp_session(page);client.send('Emulation.setCPUThrottlingRate',{'rate':4})
 page.select_option('#ship','SC-08');
 if newer:page.wait_for_function('!window.shipTest.perf().busy && !window.shipTest.perf().pending');
 result=page.evaluate('''async()=>{const c=document.querySelector('#canvas');c.setPointerCapture=()=>{};let times=[],delays=[],ticks=0;let prev=performance.now();let timer=setInterval(()=>{let n=performance.now();delays.push(n-prev);prev=n;ticks++},16);const e=(x,y)=>({clientX:x,clientY:y,pointerId:1});c.onpointerdown(e(100,100));for(let k=0;k<25;k++){let t=performance.now();c.onpointermove(e(100+k*3,100+k));times.push(performance.now()-t);await new Promise(r=>setTimeout(r,16))}c.onpointerup();await new Promise(r=>setTimeout(r,300));clearInterval(timer);return {median_handler_ms:times.sort((a,b)=>a-b)[12],max_handler_ms:Math.max(...times),max_heartbeat_ms:Math.max(...delays),ticks,preview:window.shipTest.perf?.()}}''');
 if newer:page.wait_for_function('!window.shipTest.perf().busy && !window.shipTest.perf().pending');result['settled']=page.evaluate('window.shipTest.perf()');assert result['settled']['lastMetrics']['size']==640
 client.send('Emulation.setCPUThrottlingRate',{'rate':1});page.select_option('#ship','SC-02');
 result['png']=page.evaluate('''async()=>{let b=await window.shipTest.png(false);return await new Promise(r=>{let f=new FileReader();f.onload=()=>r(f.result);f.readAsDataURL(b)})}''');
 return result
with sync_playwright() as p:
 b=p.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox']);ctx=b.new_context(viewport={'width':430,'height':900});a=bench(ctx.new_page(),old);n=bench(ctx.new_page(),r/'offline.html');b.close()
 ia,ib=[Image.open(io.BytesIO(base64.b64decode(x.pop('png').split(',')[1]))).convert('RGBA') for x in [a,n]];assert ia.size==ib.size==(2048,2048);assert ia.tobytes()==ib.tobytes(),'export mismatch';assert n['median_handler_ms']<a['median_handler_ms']/5;report={'baseline_v04':a,'worker_v05':n,'export_rgba_identical':True,'cpu_throttle':4,'device':'desktop Chromium mobile viewport 430x900'};(r/'performance_report.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
