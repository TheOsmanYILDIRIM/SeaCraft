import * as T from 'three';
import {specs} from './rigs.mjs';
export {specs};
export const defaults=Object.freeze({height:1,length:1,beam:1,ropeThickness:1,lazySag:1,standing:false,running:false,attachments:false,hardware:false,mirror:false,x:0,y:0,z:0,yaw:0});
const ranges={height:[.45,2.5],length:[.45,2.5],beam:[.45,2.5],ropeThickness:[.25,2],lazySag:[0,2],x:[-10,10],y:[-10,10],z:[-10,10],yaw:[-360,360]};
export function normalizeOptions(input={}){const o={...defaults};for(const [k,[lo,hi]] of Object.entries(ranges)){if(input[k]!==undefined){if(typeof input[k]!=='number'||!Number.isFinite(input[k])||input[k]<lo||input[k]>hi)throw Error('Invalid '+k);o[k]=input[k]}}for(const k of ['standing','running','attachments','hardware','mirror'])if(input[k]!==undefined){if(typeof input[k]!=='boolean')throw Error('Invalid '+k);o[k]=input[k]}return o}
export function partCategory(o){const n=o.name;if(/^(forestay|aft_shroud_|lateen_shroud_|outer_jibstay)/.test(n))return 'standing';if(/^(deck_eye_|eye_)/.test(n))return 'hardware';if(/_fork$|_neck$/.test(n))return 'structure';if(/_foot$|_leech(?:_[LR])?$|_luff$/.test(n))return 'structure';if(/lacing|_tie(?:_|$)|_hank_|_hoop_|^mast_hoop_|_mast_loop$|_strop$|_lashing$/.test(n))return 'attachments';if(o.userData.linePoints||/_block(?:_|$)/.test(n))return 'running';return 'structure'}
export function setRigVisibility(g,settings={}){const o={...g.userData.rigOptions,...settings};g.traverse(n=>{if(n.isMesh){const c=n.userData.rigCategory||partCategory(n);n.userData.rigCategory=c;n.visible=c==='structure'||!!o[c]}});g.userData.rigOptions=o;return g}
export function restoreRigVisibility(root){root.traverse(g=>{if(g.userData.rigOptions)setRigVisibility(g,g.userData.rigOptions)});return root}
function finishRig(g,o){g.scale.set(o.length,o.height,o.beam*(o.mirror?-1:1));g.position.set(o.x,o.y,o.z);g.rotation.y=o.yaw*Math.PI/180;g.userData.rigOptions={...o};g.userData.pose=o.mirror?'opposite tack mirrored reference':'illustrative set sail, not a wind simulation';return setRigVisibility(g,o)}
export function getDeckAnchors(g){g.updateWorldMatrix(true,false);return Object.fromEntries(Object.entries(g.userData.deckAnchors||{}).map(([k,p])=>[k,g.localToWorld(new T.Vector3(...p)).toArray()]))}

const V=(x,y,z=0)=>new T.Vector3(x,y,z), PI=Math.PI, S=Math.sin, mix=(a,b,t)=>a.clone().lerp(b,t);
const mat=(name,color,side=T.FrontSide)=>{let m=new T.MeshStandardMaterial({color,roughness:.87,side});m.name=name;return m};
export function createRig(code, options={}){
 options=normalizeOptions(options);const s=specs[code];if(!s)throw Error(code);const g=new T.Group();g.name=code;g.userData={axis:'X aft, Y up, Z starboard',type:s.type,deckY:0,normalizedMastHeight:1,pose:'illustrative set sail, not a wind simulation'};
 const wood=mat('spar',0x646464), mastmat=mat('mast',0x555555), metal=mat('collar',0x515151), rope=mat('stay',0x777777), cloth=mat('cloth',0xd2d2d2,T.DoubleSide), seam=mat('stay',0xb5b5b5);const R=.024;
 function mesh(name,geo,m){const o=new T.Mesh(geo,m);o.name=name;g.add(o);return o}
 function rod(name,a,b,r=.011,r2=r,m=wood){const d=b.clone().sub(a);if(d.length()<1e-6)throw Error(name+' zero rod');const o=mesh(name,new T.CylinderGeometry(r2,r,d.length(),24,1),m);o.position.copy(mix(a,b,.5));o.quaternion.setFromUnitVectors(V(0,1),d.normalize());return o}
 function line(name,points,r=.0032,m=rope){const path=new T.CurvePath();for(let i=1;i<points.length;i++)if(points[i].distanceTo(points[i-1])>1e-6)path.add(new T.LineCurve3(points[i-1],points[i]));const o=mesh(name,new T.TubeGeometry(path,Math.max(8,points.length*3),r*(/_neck$/.test(name)?1:options.ropeThickness),6,false),m);o.userData.linePoints=points.map(p=>p.toArray());return o}
 function curve(name,points,r=.003,m=rope){if(/lazy/.test(name)&&options.lazySag!==1){points=points.map((p,i)=>{if(i===0||i===points.length-1)return p;const base=mix(points[0],points.at(-1),i/(points.length-1));const q=p.clone();q.y=base.y+(p.y-base.y)*options.lazySag;return q})}const path=new T.CatmullRomCurve3(points);const o=mesh(name,new T.TubeGeometry(path,Math.max(12,points.length*3),r*(/_fork$|_foot$|_leech|_luff$/.test(name)?1:options.ropeThickness),6,false),m);o.userData.linePoints=path.getPoints(24).map(p=>p.toArray());return o}
 function ring(name,center,major=.027,tube=.0025,axis=V(0,1),m=rope){const o=mesh(name,new T.TorusGeometry(major,m===metal?tube:tube*options.ropeThickness,6,32),m);o.position.copy(center);o.quaternion.setFromUnitVectors(V(0,0,1),axis.clone().normalize());return o}
 const anchors={};function anchor(name,x,z){if(anchors[name])return anchors[name];let p=V(x,.018,z);anchors[name]=p;rod('deck_eye_'+name,V(x,.002,z),p,.006,.006,metal);ring('eye_'+name,p,.009,.002,V(0,0,1),metal);return p}
 function block(name,p){let o=mesh(name,new T.SphereGeometry(.009,10,8),metal);o.position.copy(p);o.scale.set(.8,1.4,.65);return p}
 function spar(name,a,b,r=.012){return rod(name,a,b,r,r*.72)}
 function lashing(name,center,axis,r=.015){for(let i=-1;i<=1;i++)ring(name+'_'+(i+1),center.clone().addScaledVector(axis,i*.0048),r,.0023,axis)}
 function parrel(name,y,contact){ring(name+'_mast_loop',V(0,y),R*1.12,.003,V(0,1));line(name+'_strop',[V(0,y,Math.sign(contact.z||1)*R),contact],.004)}
 function jaw(name,p){ // open fork, around aft half of mast; no spar traverses mast
  const y=p.y;const points=[];for(let i=0;i<=14;i++){let a=-2.0+4*i/14;points.push(V((R+.007)*Math.cos(a),y,(R+.007)*Math.sin(a)))}
  curve(name+'_fork',points,.0058,wood);line(name+'_jaw_tie',[points[0],V(-R-.005,y),points.at(-1)],.0028);line(name+'_neck',[V(R+.006,y),p],.006,wood);
 }
 function surface(name,point,tri=false){const N=32,pos=[],uv=[],idx=[],rows=[];for(let j=0;j<=N;j++){const row=[];let count=tri?N-j:N;for(let i=0;i<=count;i++){let t=j/N,u=tri?(count?i/count:0):i/N,p=point(u,t);row.push(pos.length/3);pos.push(...p.toArray());uv.push(u,1-t)}rows.push(row)}for(let j=0;j<N;j++){let a=rows[j],b=rows[j+1];for(let i=0;i<a.length-1;i++){const emit=(ia,ib,ic)=>{if(code==='SQ-D'||code==='LT-D'){let u=(uv[2*ia]+uv[2*ib]+uv[2*ic])/3,t=1-(uv[2*ia+1]+uv[2*ib+1]+uv[2*ic+1])/3;let hole=((u-.43)/.13)**2+((t-.46)/.19)**2<1+.22*S(44*u+19*t);let tear=code==='LT-D'?(u>.75+.07*S(38*t)&&t>.25&&t<.82):(t>.79+.065*S(31*u)&&u>.22&&u<.72);if(hole||tear)return;}idx.push(ia,ib,ic)};emit(a[i],b[i],a[i+1]);if(i+1<b.length)emit(a[i+1],b[i],b[i+1]);}}let geo=new T.BufferGeometry();const used=(code==='SQ-D'||code==='LT-D')?[...new Set(idx)]:Array.from({length:pos.length/3},(_,i)=>i), remap=new Map(used.map((v,i)=>[v,i]));geo.setAttribute('position',new T.Float32BufferAttribute(used.flatMap(i=>pos.slice(3*i,3*i+3)),3));geo.setAttribute('uv',new T.Float32BufferAttribute(used.flatMap(i=>uv.slice(2*i,2*i+2)),2));geo.setIndex(idx.map(i=>remap.get(i)));geo.computeVertexNormals();let o=mesh('sail_'+name,geo,cloth);o.userData={cloth:true,shape:tri?'triangle':'quadrilateral'};return o}
 function sample(fn,steps=20){return Array.from({length:steps+1},(_,i)=>fn(i/steps))}
 function edge(name,fn){curve(name,sample(fn),.0017,seam)}
 function lace(name,a,b,r,offset){const axis=b.clone().sub(a).normalize();let count=Math.max(4,Math.round(a.distanceTo(b)/.065));for(let i=0;i<=count;i++){let p=mix(a,b,i/count);ring(name+'_'+i,p,r+.002,.0018,axis);line(name+'_tie_'+i,[p.clone().add(offset.clone().multiplyScalar(.65)),p.clone().add(offset)],.0017)}}
 function halyard(name,attach,top,belay){block(name+'_block',top);line(name,[attach,top,belay],.003)}
 function sheets(name,clew){for(let side of [-1,1]){let end=anchor(name+'_'+side,code==='SQGJ-2'?.77:.60,side*.29);if(side===1)line(name+'_working',[clew,end]);else curve(name+'_lazy',[clew,mix(clew,end,.48).add(V(0,-.04,-.045)),end],.0025)}}
 if(code==='MAST-D'){
  rod('mast_stump',V(0,0),V(0,.38),R,R*.86,mastmat);
  const p=[],ix=[];for(let i=0;i<24;i++){let a=2*PI*i/24,rr=R*.86; p.push(rr*Math.cos(a),.375,rr*S(a),rr*Math.cos(a),.39+.027*S(5*a)+.014*S(9*a),rr*S(a));}p.push(0,.392,0);for(let i=0;i<24;i++){let j=(i+1)%24;ix.push(i*2,j*2,i*2+1,i*2+1,j*2,j*2+1,48,j*2+1,i*2+1)}let geo=new T.BufferGeometry();geo.setAttribute('position',new T.Float32BufferAttribute(p,3));geo.setIndex(ix);geo.computeVertexNormals();mesh('splintered_break',geo,wood);g.userData.deckAnchors={};return finishRig(g,options);
 }
 rod('mast',V(0,0),V(0,.99),R,R*.68,mastmat);rod('masthead_cap',V(0,.979),V(0,1),R*.79,R*.79,metal);
 // Standing rig. Stays and shrouds terminate at named deck eyes, not floating tips.
 const smallLug=code==='LG-1';const lateen=['LT-1','LT-L','LT-D'].includes(code);
 if(!smallLug&&!lateen){line('forestay',[V(-R,.96),anchor('bow',-.84,0)],.0038);for(let k of [-1,1])line('aft_shroud_'+k,[V(.005,.91,k*.023),anchor('shroud_'+k,.32,k*.37)],.0035)}
 if(lateen){for(let k of [-1,1])line('lateen_shroud_'+k,[V(.012,.92,k*.018),anchor('shroud_'+k,-.72,k*.38)],.0038)}
 function square(name,top,half,depth,lowerHalf,lowerYard=null){
  const ya=V(-.050,top,-half-.025),yb=V(-.050,top,half+.025);spar(name+'_yard',ya,yb,.013);parrel(name,top,V(-.05,top,0));
  const A=V(-.05,top-.018,-half),B=V(-.05,top-.018,half),C=V(-.13,top-depth,lowerHalf),D=V(-.13,top-depth,-lowerHalf);
  // Transverse yard; belly bows forward away from mast. Free clews, concave foot.
  const point=(u,t)=>{let p=mix(mix(A,B,u),mix(D,C,u),t);let k=S(PI*u);p.x-=depth*.22*k*S(PI*t)+depth*.035*k*t;p.y+=depth*.075*k*t;p.z+=(1-2*u)*.014*S(PI*t);return p};
  surface(name,point);if(code!=='SQ-D')edge(name+'_foot',u=>point(u,1));edge(name+'_leech_L',t=>point(0,t));edge(name+'_leech_R',t=>point(1,t));lace(name+'_head_lacing',V(-.05,top,-half),V(-.05,top,half),.013,V(0,-.018));
  if(name==='royal'){const p=V(-.035,.975,-.035),q=V(.06,.975,-.035);block(name+'_halyard_block',p);line(name+'_halyard',[V(-.05,top+.012),p,q,anchor(name+'_belay',.10,-.16)],.003)}else halyard(name+'_halyard',V(-.05,top+.012),V(-.03,Math.min(.975,top+.065),0),anchor(name+'_belay',-.06,-.13));
  for(let k of [-1,1]){let end=k<0?ya:yb,clew=k<0?D:C;let liftTop=V(-.018,Math.min(.98,top+.12),k*.014);line(name+'_lift_'+k,[end,liftTop],.0027);line(name+'_brace_'+k,[end,anchor(name+'_brace_'+k,.62,k*.34)],.0029);if(lowerYard){const lower=V(-.05,lowerYard.y,k*lowerYard.half);block(name+'_sheet_block_'+k,lower);line(name+'_sheet_'+k,[clew,lower,anchor(name+'_sheet_'+k,-.03,k*.17)])}else{line(name+'_sheet_'+k,[clew,anchor(name+'_sheet_'+k,.40,k*.32)]);line(name+'_tack_'+k,[clew,anchor(name+'_tack_'+k,-.49,k*.29)],.0026)} }
 }
 function gaff(top=.68,peak=.87,foot=.22,len=.57){
  const throat=V(R+.022,top,0),head=V(len*.79,peak,.055),tack=V(R+.022,foot,0),clew=V(len,foot+.015,.083);const ga=throat.clone().add(V(0,.012)),gb=head.clone().add(V(.015,.012,.002)),ba=tack.clone().add(V(0,-.013)),bb=clew.clone().add(V(.021,-.013,.003));
  spar('gaff',ga,gb,.010);spar('boom',ba,bb,.012);jaw('gaff_jaws',ga);jaw('boom_jaws',ba);
  const point=(u,t)=>{let p=mix(mix(throat,head,u),mix(tack,clew,u),t);p.z+=.067*S(PI*u)*S(PI*t);p.x-=.016*S(PI*t)*u;return p};surface('gaff',point);edge('gaff_leech',t=>point(1,t));lace('gaff_head_lacing',ga,gb,.01,V(0,-.012));lace('boom_foot_lacing',ba,bb,.012,V(0,.013));
  for(let i=0;i<=6;i++){let p=mix(throat,tack,i/6);ring('mast_hoop_'+i,V(0,p.y),R+.006,.0028,V(0,1));line('luff_tie_'+i,[V(R+.006,p.y),p],.002)}
  halyard('throat_halyard',ga,V(.033,Math.min(.95,top+.13),.012),anchor('throat_belay',.07,-.14));
  const b1=mix(ga,gb,.38),b2=mix(ga,gb,.82),p=V(.035,Math.min(.975,peak+.09),.015);block('peak_bridle_block',p);line('peak_halyard_bridle',[b1,p,b2],.003);line('peak_halyard_fall',[p,anchor('peak_belay',.07,.14)],.0028);
  line('boom_topping_lift',[bb,V(.02,.95,-.018)],.0025);sheets('main_sheet',bb);
 }
 function jib(low=false){
  // Head and tack are on the sloping forestay; the third corner is FREE and sheeted aft.
  const stayTop=V(-R,.96),stayBottom=anchors.bow||anchor('bow',-.84,0),head=mix(stayTop,stayBottom,low?.39:.12),tack=mix(stayTop,stayBottom,.92),clew=V(low?-.29:-.19,low?.15:.24,.085);
  const point=(u,t)=>{let p=mix(mix(head,tack,u),clew,t);p.z+=.048*4*u*(1-u)*(1-t)*S(PI*t);return p};surface('jib',point,true);edge('jib_leech',t=>point(0,t));edge('jib_foot',t=>point(1,t));
  for(let i=0;i<=7;i++){let p=mix(head,tack,i/7);ring('jib_hank_'+i,p,.006,.0018,stayBottom.clone().sub(stayTop));}
  halyard('jib_halyard',head,V(-.035,.98,.012),anchor('jib_belay',-.10,.12));line('jib_tack_lashing',[tack,stayBottom],.003);for(let k of [-1,1]){let end=anchor('jib_sheet_'+k,.19,k*.29);if(k===1)line('jib_sheet_working',[clew,end]);else curve('jib_sheet_lazy',[clew,mix(clew,end,.5).add(V(0,-.025,-.03)),end],.0025)}
 }
 function lateenRig(low=false){
  // True triangular lateen: long yard rises aft; tack at forward low end, clew aft.
  const A=V(-.57,low?.16:.22,.056),B=V(.43,low?.76:1.10,.10),C=V(.57,low?.14:.20,.19);const ya=A.clone().add(V(-.035,-.03)),yb=B.clone().add(V(.033,.029));spar('lateen_yard',ya,yb,.014);const t=-ya.x/(yb.x-ya.x),p=mix(ya,yb,t);parrel('lateen_parrel',p.y,p);halyard('lateen_halyard',p,V(0,.98,.034),anchor('lateen_belay',.07,-.12));
  const point=(u,t)=>{let q=mix(mix(A,B,u),C,t);q.z+=.085*4*u*(1-u)*(1-t)*S(PI*t)+.018*S(PI*t)*(1-t);return q};surface('lateen',point,true);if(code!=='LT-D')edge('lateen_leech',t=>point(1,t));edge('lateen_foot',t=>point(0,t));lace('lateen_head_lacing',A,B,.014,V(0,-.008,.003));line('lateen_tack',[A,anchor('lateen_tack',-.64,.025)]);sheets('lateen_sheet',C);line('lateen_yard_downhaul',[ya,anchor('yard_downhaul',-.55,-.20)],.003);
 }
 function lug(){
  // Standing lug, loose-footed. Yard extends forward, peak aft; tack near mast.
  const A=V(-.25,.70,.052),B=V(.43,.99,.083),C=V(.58,.20,.17),D=V(-.06,.23,.05);const ya=A.clone().add(V(-.022,.009)),yb=B.clone().add(V(.022,.009));spar('lug_yard',ya,yb,.012);let p=mix(ya,yb,-ya.x/(yb.x-ya.x));parrel('lug_parrel',p.y,p);halyard('lug_halyard',p,V(0,.98,.03),anchor('lug_belay',.06,-.10));
  const point=(u,t)=>{let q=mix(mix(A,B,u),mix(D,C,u),t);q.z+=.09*S(PI*u)*S(PI*t);q.y+=.025*S(PI*u)*t;return q};surface('lug',point);edge('lug_luff',t=>point(0,t));edge('lug_leech',t=>point(1,t));edge('lug_foot',u=>point(u,1));lace('lug_head_lacing',ya,yb,.012,V(0,-.009));line('lug_tack_downhaul',[D,anchor('lug_tack',-.06,.025)]);sheets('lug_sheet',C);
 }
 function doubleHeadsail(){
  // Two distinct stays: inner on stem, outer on bowsprit. Inner sail stays aft of outer.
  const outerEnd=anchor('bowsprit_tack',-1.12,0),outerTop=V(-.025,.98,0),innerEnd=anchors.bow,innerTop=V(-R,.96);
  spar('bowsprit',V(-.68,.045),V(-1.14,.018),.018);line('outer_jibstay',[outerTop,outerEnd],.0032);
  function headSail(name,A,B,C,top,bottom){const point=(u,t)=>{let p=mix(mix(A,B,u),C,t);p.z+=.022*4*u*(1-u)*(1-t)*S(PI*t);return p};surface(name,point,true);edge(name+'_leech',t=>point(0,t));edge(name+'_foot',t=>point(1,t));for(let i=0;i<=6;i++)ring(name+'_hank_'+i,mix(A,B,i/6),.006,.0016,bottom.clone().sub(top));line(name+'_tack',[B,bottom],.0025);
   // Halyard first follows stay to its head; fall is routed on opposite side of mast.
   const lead=V(top.x,top.y,-.035);line(name+'_halyard',[A,top,lead,anchor(name+'_belay',-.09,-.18)],.0025);
   for(let k of [-1,1]){let end=anchor(name+'_sheet_'+k,name==='jib'?-.32:.18,k*.30);if(name==='jib'&&k===-1)curve(name+'_sheet_'+k,[C,V(-.89,.21,-.10),V(-.85,.10,-.27),end],.0024);else line(name+'_sheet_'+k,[C,end],.0024)}
  }
  headSail('staysail',mix(innerTop,innerEnd,.29),mix(innerTop,innerEnd,.94),V(-.22,.17,.105),innerTop,innerEnd);
  headSail('jib',mix(outerTop,outerEnd,.07),mix(outerTop,outerEnd,.97),V(-.79,.26,.10),outerTop,outerEnd);
 }
 function triangle(){
  const A=V(.038,.91,0),B=V(.043,.19,0),C=V(.56,.205,.105);const ba=B.clone().add(V(0,-.015)),bb=C.clone().add(V(.015,-.015));spar('triangle_boom',ba,bb,.012);jaw('triangle_boom_jaw',ba);
  const point=(u,t)=>{let q=mix(mix(A,B,u),C,t);q.z+=.08*4*u*(1-u)*(1-t)*S(PI*t);return q};surface('triangle',point,true);edge('triangle_leech',t=>point(0,t));edge('triangle_foot',t=>point(1,t));for(let i=0;i<=9;i++){let p=mix(A,B,i/9);ring('triangle_luff_hoop_'+i,V(0,p.y),R+.006,.0025,V(0,1));line('triangle_luff_tie_'+i,[V(R+.006,p.y),p],.0018)}lace('triangle_foot_lacing',ba,bb,.012,V(0,.015));halyard('triangle_halyard',A,V(.033,.97,.01),anchor('triangle_belay',.08,-.14));line('triangle_topping_lift',[bb,V(.02,.97,-.018)],.0025);sheets('triangle_sheet',bb);
 }
 function squareStack(n){let data=n===3?[[.41,.35,.25,.38],[.67,.26,.20,.30],[.91,.17,.18,.21]]:[[.34,.35,.21,.38],[.55,.28,.17,.32],[.74,.21,.15,.25],[.88,.14,.12,.18]];let names=['course','topsail','topgallant','royal'];for(let i=0;i<n;i++){let [top,w,h,low]=data[i];square(names[i],top,w,h,low,i?{y:data[i-1][0],half:data[i-1][1]}:null)}}
 switch(code){case 'SQ-D':case 'SQ-1':square('course',.79,.38,.45,.40);break;case 'SQ-2':square('course',.53,.35,.31,.38);square('topsail',.87,.24,.28,.30,{y:.53,half:.35});break;case 'SQ-3':squareStack(3);break;case 'SQ-4':squareStack(4);break;case 'GF-H':gaff(.42,.58,.19,.41);break;case 'TRJ-L':triangle();jib(true);break;case 'TR-1':triangle();break;case 'GF-1':gaff();break;case 'JB-1':jib();break;case 'JB-L':jib(true);break;case 'JB-2':doubleHeadsail();break;case 'GFJ-1':gaff();jib();break;case 'LT-D':case 'LT-1':lateenRig();break;case 'LT-L':lateenRig(true);break;case 'LG-1':lug();break;case 'SQG-H':case 'SQGJ-2':case 'SQG-1':{const tall=code!=='SQG-1';if(tall)gaff(.48,.66,.13,code==='SQGJ-2'?.70:.57);else gaff(.39,.57,.14,.49);const y=tall?.70:.60,h=tall?.27:.32;const a=V(-.05,y,-h-.025),b=V(-.05,y,h+.025);spar('bare_lower_yard',a,b,.012);parrel('lower_yard_parrel',y,V(-.05,y,0));halyard('lower_yard_halyard',V(-.05,y+.012),V(-.035,tall?.78:.68,0),anchor('lower_yard_belay',-.06,.13));for(let k of [-1,1]){let end=k<0?a:b;line('lower_yard_lift_'+k,[end,V(-.02,tall?.86:.76,k*.016)],.0027);line('lower_yard_brace_'+k,[end,anchor('lower_yard_brace_'+k,.62,k*.34)],.0029)}square('topsail',tall?.91:.89,tall?.17:.24,tall?.19:.26,tall?.23:.29,{y,half:h});}if(code==='SQGJ-2')doubleHeadsail();break;}
 g.userData.deckAnchors=Object.fromEntries(Object.entries(anchors).map(([k,v])=>[k,v.toArray()]));
 return finishRig(g,options);
}
