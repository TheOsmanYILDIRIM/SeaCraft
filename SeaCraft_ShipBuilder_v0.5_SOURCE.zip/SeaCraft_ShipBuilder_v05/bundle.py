from pathlib import Path
import json,re,posixpath
r=Path(__file__).parent; files=['lib/package/build/three.core.js','lib/package/build/three.module.js','lib/package/examples/jsm/exporters/GLTFExporter.js','lib/package/examples/jsm/utils/BufferGeometryUtils.js','ship.mjs','decor.mjs','ports.mjs','engine.mjs','rigs.mjs','presets.mjs','render.mjs','preview-worker.mjs'];sources={k:(r/k).read_text() for k in files};html=(r/'viewer.html').read_text();body=html.split('<script type="importmap">')[0];sources['main.mjs']=html.split('<script type="module">')[1].split('</script>')[0];aliases={'three':'lib/package/build/three.module.js','three/addons/exporters/GLTFExporter.js':'lib/package/examples/jsm/exporters/GLTFExporter.js'}
for k,s in list(sources.items()):
 def repl(m):
  n=m.group(2); target=aliases.get(n,posixpath.normpath(posixpath.join(posixpath.dirname(k),n)))
  return m.group(1)+"'@@"+target+"@@'" if target in sources and target!=k else m.group(0)
 sources[k]=re.sub(r'(\bfrom\s+)[\'"]([^\'"]+)[\'"]',repl,s)
script='const sources='+json.dumps(sources).replace('</script','<\\/script')+';const urls={};function mod(k){if(urls[k])return urls[k];let s=sources[k].replace(/@@([^@]+)@@/g,(_,n)=>mod(n));return urls[k]=URL.createObjectURL(new Blob([s],{type:"text/javascript"}));}globalThis.__shipWorkerURL=mod("preview-worker.mjs");import(mod("main.mjs")).catch(e=>{document.body.append(String(e));console.error(e)});'
(r/'offline.html').write_text(body+'<script>'+script+'</script></html>')
# Classic, self-contained worker: nested blob ESM imports fail in null-origin/mobile file viewers.
# Only the Three.js core is needed for procedural geometry and software rendering.
worker_files=['lib/package/build/three.core.js','rigs.mjs','engine.mjs','decor.mjs','ports.mjs','ship.mjs','render.mjs','preview-worker.mjs']
keys={k:'W'+str(i) for i,k in enumerate(worker_files)}
chunks=[]
for k in worker_files:
 s=(r/k).read_text();exports={}
 def target(n):return keys['lib/package/build/three.core.js' if n=='three' else posixpath.normpath(posixpath.join(posixpath.dirname(k),n))]
 def imports(m):
  spec,n=m.groups();a=target(n)
  if spec.startswith('* as '):return 'const '+spec[5:]+'='+a+';'
  return 'const '+re.sub(r'\s+as\s+',':',spec)+'='+a+';'
 s=re.sub(r'(?m)^import\s+(\* as \w+|\{[^}]+\})\s+from\s+[\'\"]([^\'\"]+)[\'\"];',imports,s)
 def reexports(m):
  names,n=m.groups()
  for v in names.split(','):
   a,*b=v.strip().split(' as ');exports[b[0] if b else a]=target(n)+'.'+a
  return ''
 s=re.sub(r'\bexport\s*\{([^}]+)\}\s*from\s*[\'\"]([^\'\"]+)[\'\"];',reexports,s)
 def named(m):
  for v in m.group(1).split(','):
   a,*b=v.strip().split(' as ');exports[b[0] if b else a]=a
  return ''
 s=re.sub(r'\bexport\s*\{([^}]+)\}\s*;',named,s)
 def declaration(m):
  kind,name=m.groups();exports[name]=name;return kind+' '+name
 s=re.sub(r'\bexport\s+(const|let|var|function|class)\s+(\w+)',declaration,s)
 chunks.append('const '+keys[k]+'=(()=>{\n'+s+'\nreturn {'+','.join(a+':'+b for a,b in exports.items())+'};\n})();')
worker_source='\n'.join(chunks)
(r/'preview-worker.bundle.js').write_text(worker_source)
html=(r/'offline.html').read_text();html=html.replace('globalThis.__shipWorkerURL=mod("preview-worker.mjs");','globalThis.__shipWorkerURL=URL.createObjectURL(new Blob(['+json.dumps(worker_source).replace('</script','<\\/script')+'],{type:"text/javascript"}));')
(r/'offline.html').write_text(html)
