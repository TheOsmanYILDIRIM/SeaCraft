from pathlib import Path
from playwright.sync_api import sync_playwright
import json
r=Path(__file__).parent
with sync_playwright() as p:
 b=p.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox']);page=b.new_page(viewport={'width':430,'height':900},has_touch=True,is_mobile=True);errors=[];page.on('pageerror',lambda e:errors.append(str(e)));page.set_content((r/'offline.html').read_text());page.wait_for_function('window.ready && window.shipTest.perf().completed>0');page.select_option('#ship','SC-08');page.wait_for_function('!window.shipTest.perf().busy');
 # While a CD worker is active, switch back to single view and alter a hull parameter.
 page.evaluate('''()=>{document.querySelector('#cd').click();document.querySelector('#iso').click();let i=document.querySelector('#hull input[type=range]');i.value='6.15';i.dispatchEvent(new Event('input',{bubbles:true}))}''');page.wait_for_function('window.shipTest.perf().lastMetrics?.size===640 && !window.shipTest.perf().busy && !window.shipTest.perf().pending && window.shipTest.state().preset.length===6.15');assert 'ortografik' in page.locator('#status').inner_text();
 # Touch-driven camera movement using Chromium's native touch events.
 c=page.locator('#canvas');c.scroll_into_view_if_needed();box=c.bounding_box();x=box['x']+box['width']*.5;y=box['y']+box['height']*.5;session=page.context.new_cdp_session(page);before=page.evaluate('window.shipTest.perf().completed');session.send('Input.dispatchTouchEvent',{'type':'touchStart','touchPoints':[{'x':x,'y':y}]});
 for k in range(1,16):session.send('Input.dispatchTouchEvent',{'type':'touchMove','touchPoints':[{'x':x+k*3,'y':y+k}]});page.wait_for_timeout(16)
 session.send('Input.dispatchTouchEvent',{'type':'touchEnd','touchPoints':[]});page.wait_for_function(f'window.shipTest.perf().completed>{before} && !window.shipTest.perf().busy && window.shipTest.perf().lastMetrics?.size===640');assert not errors,errors;result={'native_chromium_touch':True,'switch_while_cd_busy':True,'slider_change':True,'settled_preview_size':640,'worker':page.evaluate('window.shipTest.perf().backend')};b.close()
(r/'worker_interactions_report.json').write_text(json.dumps(result,indent=2));print(result)
