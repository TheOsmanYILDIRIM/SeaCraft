# SeaCraft — İlk küçük ada grubu

Görsel olarak kabul edilen 9 özgün ada PNG dosyası. Kaynak piksel verisi değiştirilmemiştir. IS-08 ve IS-10 benzerlik nedeniyle dışarıda tutulmuştur; numaralar korunur.

Dosyalar 1254 × 1254 RGBA, şeffaf arka planlı tekil sprite kaynaklarıdır. Geometri referanslarıyla kesin seed eşlemesi mevcut değildir.

GitHub aktarımı için kaynak pakettir, doğrudan oyun entegrasyonu değildir. Alpha kenar temizliği, dünya ölçeği, kıyı maskesi/collision, mobil okunaklılık ve cihaz kabulü entegrasyonda ayrıca doğrulanmalıdır.

Üretim standardı: https://github.com/TheOsmanYILDIRIM/SeaCraft/blob/main/GELISTIRME_GOREV_PLANI.md
