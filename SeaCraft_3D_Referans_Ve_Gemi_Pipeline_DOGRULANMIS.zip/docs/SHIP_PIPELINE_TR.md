# SeaCraft — sıfırdan gemi üretimi → GitHub yükleme ZIP'i

Bu belge gerçek SC-02 ve SC-03 iş akışını ve `SeaCraft/GEMI_SPRITE_URETIM_REHBERI.md` kanonik sözleşmesini birlikte açıklar. Kanonik belge çelişirse o üstündür.

## 0. Kanonik gemi fişini oku

`GEMI_GORSEL_TASARIM_VE_SPRITE_PLANI.md`: 15 geminin her biri için gövde L/B oranı, güverte, port, silah, direk/yelken sayısı, renk, amblem ve negatif kısıtları içerir. Gemiler yalnız büyük/küçük recolor değildir. Kamera ortografik, 55° yükseklik, zero roll, sabit ışık ve N/NE/E/SE/S/SW/W/NW yön standardı korunur.

SC-03: 3:1 geniş kargo gövdesi, içe kapanan borda, armut kıç, 1 büyük merkezi ambar kapağı, açık çalışma güvertesi + ambar, **3 kısa direk**, ön ve ortada **birer tek kare yelken**, kıçta **tek küçük latin yelkeni**, askeri port/top **yok**.

## 1. Tekrarlı kullanılabilir yelken referans kütüphanesi

Birleşik 3 direkli `SC-03 arma görseli` üretmek zorunlu DEĞİL. Modüller gövdeden bağımsız ve renksiz 4 görünüşlü 2×2 kare clay referanslarıdır. Yerleşim yalnız nihai AI promptunda tarif edilir.

- **SQ-1**: bir direk/tek kare yelken (hazır)
- **SQ-2**: bir direk/iki kat kare yelken (hazır)
- **GF-1**: gaff ana yelken (hazır; örnekte flokla birleşik demonstrasyon var)
- **JB-1**: dar flok (hazır)
- **LT-1**: eğik serenli latin yelkeni (hazır)

SC-02 için GF-1 + JB-1. SC-03 için **ön SQ-1 + ana SQ-1 + kıç LT-1**. SQ-1'in SC-03 için daha kısa ve geniş yapılması **prompt farkıdır**, yeni SQ-1B varlığı üretilmesi gerekmez. Gelecekte diğer gemilerin modül reçetesi ayrı tanımlanır; henüz üretilmemiş modül gerektiğinde sadece o tip üretilir.

## 2. 3D kamera/geometri referansları

Ortak GLB kamera referansı SC-02/SC-03 gerçek gemi tasarımı DEĞİLDİR. `code/generate_glb_8view_refs.py` tek GLB ile iki pano üretir:

1. **Normal/dokulu 8 yön**: 55° ortografik kamera, sekiz yön ve boş merkezli radial dizilim/ölçek.
2. **Renkli 8 yön**: pruva/kıç/iskele/sancak ve direk bölümünün 45° dönüşte aynı fiziksel gövdenin değişmez parçası olduğunu anlatan tanısal renk kılavuzu.

Renkli panodaki renkler nihai gemiye geçmez; o geminin mevcut gövdesi de kopyalanmaz. 1280² radiale 8 gemiyi temas etmeyecek şekilde yerleştir; `%10 küçük` sürüm sınır emniyetidir; yeni tek gemi görselinde bile kesilme/temas ayrı kontrol edilir.

## 3. Malzeme referansı

**Ayrı** SeaCraft texture atlası `assets/SeaCraft_texture_atlas_source.png` yüklenir. AI promptu ahşap/yelken/metal/halat için ATLAS içindeki örnekleri baz alır; her geminin ahşap tonu, kir/ıslaklık, kumaş rengi farkları tarif edilir. Malzeme ailesi sıfırdan rastgele icat edilmez. Bu atlas `.glb` modelinin doku atlası değildir.

## 4. Nihai radial AI görsel üretimi — SC-03 örneği

Tek bir **STRICT 1:1 SQUARE** PNG içinde tam **8** gemi, **pruvalar merkeze** bakar. Ref sırası:
1. normal 8-yön kamera/kompozisyon;
2. renkli 8-yön geometri sürekliliği;
3. malzeme/texture atlas;
4. SQ-1 (ön + orta, toplam 2);
5. LT-1 (kıç, toplam 1).

Gemi gövdesi **SC-03 kanonik fişinden** üretilir, başka referans gemisinden kopyalanmaz. Kullanılan tam prompt `docs/PROMPTS_TR.md` içinde. Model cevabında 8 ayrı ve birbirinden kopuk görünüş (non-touching), sabit kamera, 3 direk, 2 kare + 1 latin yelken, ağır tüccar gövdesi, hiçbir top/port olmaması QA zorunludur. Ref modelin üç direği olmadığı için SC-03 gemisini model geometrisinden üretmeye çalışma.

## 5. Radial kesim ve kaynak çözünürlük kapısı

Kanonik `tools/sprite_radial_extract.py --facing inward` şeffaf panoda 8 büyük alfa bağlı bileşeni ayırır; sabit wedge kesmek doğru değildir. Eğer komşu gemiler birbirine değiyorsa üretim aşamasına geri dön, yamalı kesim başarı değildir. `extraction_contactsheet.png` görsel kontrolünden sonra tekil gerçek kaynak çözünürlüğü kontrol edilir. Ayrıntı düşükse **AI upscale gerekli** bildir; upscale yalnız kullanıcı tarafından/harici araçla, bölünmüş ham yönlerde, normalize/ShowLook öncesi yapılır.

## 6. Kanonik normalizasyon ve renk aşamaları

`tools/sprite_normalize.py raw/ normalized/`:
- 55° projeksiyon oranlı tek dünya ölçeği ve 180° çift kilidi;
- yoğun gövde/su hattı support-anchor otomatik aday;
- kırpmayan `compose_no_crop()`;
- N yönü hedefli Lab/LUT renk eşitleme.

`tools/seacraft_showlook.py normalized/ style_reference.png showlook/ --stage v3`:
- ahşap/yelken/metal için material-aware global görünüm;
- filmic ton, soğuk gölge, kontrol edilmiş sıcak ahşap ve kirli keten;
- geometriye, konuma, alfaya dokunmaz. Görsel referans atlası otomatik ShowLook stil görüntüsüyle aynı şey değildir; kullanılan `style_reference.png` ayrıca saklanmalı. Ara grade kaynak dokuyu gereğinden sert gösterirse ayar kanonik araçta düzeltilir, gemiye özel sharpen/denoise uygulanmaz.

## 7. Görsel merkezleme ve kullanıcı JSON'u

Önce 1024² şeffaf, renkleri normalize edilmiş 8 yönün 4×2 kontaktı ve 8-yön dönen GIF'i kontrol edilir. Otomatik pivot, mast ucundan değil **gövdenin denize oturduğu destek merkezinden** türetilir. Belirgin sıçrama varsa `--no-support-anchor` alternatifini karşılaştır; tekil elle pivot düzeltmesi gerektiğinde repo `tools/sprite_manual_aligner_template.html` kullanılır.

Gömülü mobil HTML'de kullanıcı her yön için x/y/scale ayarlar, 7 FPS ve ghost ile kıyaslar, **`sprite_manual_alignment.json`** dışa aktarır. SC-03'ün gerçek kullanıcı JSON'u `assets/SC03_manual_alignment.json` içinde; bu hizalama sonraki paket için kabul kaynağıdır.

## 8. Yön geçişi ve dalga / oyun motoru

Ana sprite atlası **yalnız 8 yön** taşır, ara açılar ayrı PNG diye saklanmaz. Oyun içi görsel sunumda bir yöne +10° yaklaşma ve sonraki yönden -10° giriş ayrı Sprite2D dönüşleriyle yapılabilir; arada alfa harmanlama / koyu silüet doldurma gerekli değil. Bu 10° görsel sallanma **gerçek fiziksel baş açısından ayrıdır**. Dalga yalpası, batıp çıkma, köpük ve wake ayrı katman/etki; ana sprite'a pişirilmez. 7 FPS inceleme ve 21 FPS görsel GIF kanıttır, Godot Android entegrasyon testi yerine geçmez.

## 9. Final oyun atlası ve GitHub teslim ZIP'i

Kanonik final ZIP **tam 12 dosyadır**: `N,NE,E,SE,S,SW,W,NW.png` (8), `atlas_4x2.png` (1), `rotation.gif` (1), `manifest.json` (1), orijinal değişmemiş radial PNG (1). **SC-03 için hücre 224×224**, atlas **896×448**, final pivot (112,112). Ana master 1024²; oyun hücresi 224², kenarda her karede minimum **8 alfa-0 piksel**. 4×2 sıra N NE E SE / S SW W NW. `rotation.gif` ShowLook sonrası final karelerden yeniden üretilmeli. Manifest: gemi ID, pivot, yön, orijinal SHA, normalize modu, ShowLook sürümü, kaynak çözünürlüğü ve padding. Kod/renksiz referans/GLB/texture atlas final oyun ZIP'ine **girmez**; bunlar ayrı tekrar-üretilebilir geliştirme arşivinde tutulur.

GitHub yükleme: <https://github.com/TheOsmanYILDIRIM/SeaCraft/upload/main>. ZIP'i arşiv olarak depoya koymak, içindeki PNG'leri çalışma ağacındaki oyun sprite klasörüne otomatik çıkarmak/anlık oyunda çalıştırmak değildir. Gerçek Godot entegrasyonu ayrı kod/CI ve Android üzerinde görsel test ister.

## 10. SC-03 gerçek teslim/girdi kimliği

- AI radial: `assets/SC03_approved_radial_source.png` (126785.png, önceki temaslı denemelerin yerine)
- kullanıcı onaylı hizalama: `assets/SC03_manual_alignment.json`
- final ZIP: `assets/SC03_FINAL_MANUAL_ALIGNED_GITHUB_UPLOAD.zip`
- 12 dosyalık final paketin çekirdeği bu ayrı ZIP'dedir; bu geliştirme arşivi aynı şeyi yeni bir final oyun paketi olarak üretmez.
