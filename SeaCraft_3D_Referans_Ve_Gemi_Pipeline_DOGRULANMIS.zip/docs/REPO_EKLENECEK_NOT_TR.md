# Kanonik rehbere önerilen ek — 3D referans / modüler arma / SC-03

- Ortak GLB: `sample_2026-11-22T165909.224.glb` (kamera proxy; SC-03 kimliği değildir).
- Doğrulanmış 3D yeniden üretim kodu: `code/generate_glb_8view_refs.py` (Numba CPU; 55° ortografik, Y-up→Z-up, sekiz yön, %90 ölçek, 1280² panoda non-overlap).
- İki ayrı referans: **dokulu/normal 8 yön** sadece kamera/kompozisyon; **renkli geometri 8 yön** sadece pruva-kıç/bordalar/süreklilik; tanılama renkleri final sprite'a kopyalanmaz.
- Model tek birleşik mesh olduğundan renkli bölgeleme konumsal tahmindir; özgün segment ID'leri geri çıkarılamaz.
- Texture atlas **ayrı** malzeme referansıdır; ortak GLB texture'ıyla karıştırma.
- Renksiz clay arma kütüphanesi SQ-1, SQ-2, GF-1, JB-1, LT-1. Her gemi için gerekenden **sadece eksik modül** oluşturulur. SC-03: SQ-1 + SQ-1 + LT-1; SQ-1 daha kısa/geniş oranla prompt içinde uyarlanır, gerekmedikçe SQ-1B varyantı üretilmez.
- Doğrudan 8 yön tek kare radial AI üretim; temas kontrolü → kanonik extractor → kaynak çözünürlük kapısı → normalizer N-Lab/LUT → ShowLook v3 → kullanıcı JSON hizalama QA → 8 master + 4x2 final atlas → **12 dosyalık ZIP**.
- Oyunda yalnız sekiz gerçek kare; ±10° görsel açı katmanı Godot'ta, dalga yalpası/bat-kalk ayrı, blend/ara sprite yok. `rotation.gif` yalnız önizlemedir.
- Geliştirme/ref arşivi ile 12 dosyalık oyun sprite teslim paketi **farklıdır**. Eski ref paketi ilk kod taslağı çalıştırılmadan yüklenmiştir; bu paket doğrulanmış kodla onun yerine geçer.
