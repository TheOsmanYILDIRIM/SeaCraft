# SeaCraft — tekrar üretilebilir 3D kamera/geometri referansları ve gemi üretim arşivi

Bu paket, SeaCraft 8 yön gemi üretiminin **referans** kısmını ve SC-03 pilotunda uygulanan **ayrı oyun sprite üretim hattını** belgelendirir.

## En önemli ayrım

- `model/` ve `outputs/verified/`: **ortak 3D kamera ve geometri kılavuzu**. Bu model SC-03 değildir, oyun içi gemi yerine kullanılmaz.
- `assets/SeaCraft_texture_atlas_source.png`: görsel malzeme kütüphanesi; 3D GLB'nin kendi dokusundan farklıdır.
- `sail_refs/`: gemilere göre kombinlenen ayrı renksiz yelken referansları. Nihai gemi sprite'ı değildir.
- `assets/SC03_approved_radial_source.png`: AI modelinden çıkan gerçek SC-03 gemi panosu.
- `assets/SC03_FINAL_MANUAL_ALIGNED_GITHUB_UPLOAD.zip`: bu pano için zaten üretilmiş ayrı **12 dosyalık oyun varlığı** (referans üreticiyle karıştırılmamalı).

## Hızlı çalıştırma

Python 3.10+ ve `pip install numpy pillow trimesh numba` gerekir. Sonuçları üretmek için Blender veya internet gerekmez.

```bash
python code/generate_glb_8view_refs.py --glb model/sample_2026-11-22T165909.224.glb --outdir rendered --size 420 --scale 0.90 --elevation 55
```

`rendered/recreated_8view_normal.png`, `rendered/recreated_8view_colored.png`, şeffaf varyantlar, `normal_N.png` … `colored_NW.png` ve `render_report.json` çıkar. Örnek **gerçek çalıştırma** sonuçları `outputs/verified/` içinde.

## Yeniden üretim kontrolü

- 83.035 köşe, 95.584 üçgen, GLB içine gömülü 1024² albedo dokusu.
- `Y-up` GLB koordinatları `Z-up` dünya uzayına çevrildi.
- Sabit ortografik 55° kamera, dünya ölçüsü sabit, 8 ayrı 45° baş yönü.
- Pruvalar dairesel panonun merkezine dönük. 1280² karede %90 ölçek; **8 ayrı alfa bölgesi, temas yok**.
- CPU/Numba z-buffer, gerçek UV dokusu; iki ardışık çalıştırma **byte-for-byte aynı PNG** üretir.
- `colored` renklerinin tamamı konumsal *heuristic* segmentasyondur. Asıl GLB tek birleşik geometri taşıdığı için eski panonun bölge kimliği birebir geri çıkarılamaz.
- Tarihî eski referanslarla görüntü eşitliği iddia edilmez; `outputs/comparison_old_vs_verified.png` farkları gösterir.

## Süreç belgeleri

- `docs/SHIP_PIPELINE_TR.md`: sıfırdan gemi ile GitHub ZIP'ine kadarki tam sıra ve karar kapıları.
- `docs/PROMPTS_TR.md`: kullanılan SC-03 beş referanslı **tam üretim promptu** ve LT-1 promptu.
- `docs/REPO_EKLENECEK_NOT_TR.md`: repo kanonik rehberi için özet.
- `docs/VERIFICATION.json`: dosya, tekrar üretilebilirlik ve görsel kontrol kanıtı.

## Kritik eksikler ve düzeltmeler

Önceki taslak betiğin eksenleri, kamera dönüşleri ve gerçek çalıştırma kanıtı eksikti. Bu arşivdeki betik bunların yerine geçer. Önceki 8 yön PNG'leri tarihî karşılaştırma girdisidir; doğrulanmış yeni çıktılar `outputs/verified/` altındadır.

**Not:** `.glb` varlığının lisans/sahiplik bilgisi burada doğrulanmadı; üçüncü taraf paylaşımında ayrıca denetlenmeli. Bu paket kendi kullanımına uygun geliştirme arşividir.
