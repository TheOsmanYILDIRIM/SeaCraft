#!/usr/bin/env python3
"""Reproducible SeaCraft eight-direction 3D reference renderer (CPU/Numba).

Requirements: numpy, pillow, trimesh, numba. No Blender, GPU or network.
This uses the ACTUAL vertices, triangles, UVs and embedded GLB texture.
The diagnostic-color scheme is recreated heuristically: the original authoring
mesh has one merged mesh and does not retain original part IDs.

Example:
python generate_glb_8view_refs.py --glb sample.glb --outdir out --size 420 --scale .90
"""
import argparse
import json
import math
from pathlib import Path
import numpy as np
from PIL import Image, ImageDraw
import trimesh
from numba import njit

ORDER = ('N','NE','E','SE','S','SW','W','NW')
# Inward bows; screen angle is measured clockwise from screen-right (y down).
BOW_SCREEN_DEG = {'N':270,'NE':315,'E':0,'SE':45,'S':90,'SW':135,'W':180,'NW':225}  # model bow is -X
CENTERS = {'N':(640,216),'NE':(949,347),'E':(1030,640),'SE':(949,933),
           'S':(640,1064),'SW':(331,933),'W':(250,640),'NW':(331,347)}

@njit(cache=True)
def _render(triangles, uvtri, facecolor, shade, texture, size):
    frame = np.zeros((size,size,4), dtype=np.uint8)
    depth = np.full((size,size),-1.e20,dtype=np.float32)
    th, tw = texture.shape[:2]
    for i in range(triangles.shape[0]):
        x0,y0,z0=triangles[i,0,0],triangles[i,0,1],triangles[i,0,2]
        x1,y1,z1=triangles[i,1,0],triangles[i,1,1],triangles[i,1,2]
        x2,y2,z2=triangles[i,2,0],triangles[i,2,1],triangles[i,2,2]
        xmin=max(0,int(math.floor(min(x0,x1,x2))))
        xmax=min(size-1,int(math.ceil(max(x0,x1,x2))))
        ymin=max(0,int(math.floor(min(y0,y1,y2))))
        ymax=min(size-1,int(math.ceil(max(y0,y1,y2))))
        if xmin>xmax or ymin>ymax: continue
        den=(y1-y2)*(x0-x2)+(x2-x1)*(y0-y2)
        if abs(den)<1.e-8: continue
        inv=1./den
        for y in range(ymin,ymax+1):
            for x in range(xmin,xmax+1):
                a=((y1-y2)*(x+.5-x2)+(x2-x1)*(y+.5-y2))*inv
                if a < -1.e-5: continue
                b=((y2-y0)*(x+.5-x2)+(x0-x2)*(y+.5-y2))*inv
                c=1.-a-b
                if b < -1.e-5 or c < -1.e-5: continue
                z=a*z0+b*z1+c*z2
                if z<=depth[y,x]: continue
                if facecolor[i,3] > 0:  # diagnostic/colored
                    red=facecolor[i,0]; green=facecolor[i,1]; blue=facecolor[i,2]; opacity=255
                else:
                    u=a*uvtri[i,0,0]+b*uvtri[i,1,0]+c*uvtri[i,2,0]
                    v=a*uvtri[i,0,1]+b*uvtri[i,1,1]+c*uvtri[i,2,1]
                    xx=min(tw-1,max(0,int((u%1.)*(tw-1))))
                    yy=min(th-1,max(0,int((1.-(v%1.))*(th-1))))
                    red=texture[yy,xx,0]; green=texture[yy,xx,1]; blue=texture[yy,xx,2]
                    opacity=texture[yy,xx,3]
                if opacity<10:continue
                depth[y,x]=z
                light=shade[i]
                frame[y,x,0]=min(255,int(red*light))
                frame[y,x,1]=min(255,int(green*light))
                frame[y,x,2]=min(255,int(blue*light))
                frame[y,x,3]=opacity
    return frame


def get_mesh_and_texture(glb, override=None):
    scene=trimesh.load(str(glb),force='scene')
    # scene.dump(concatenate=True) applies node transforms, unlike taking arbitrary raw geometry
    mesh=scene.to_geometry()
    if not isinstance(mesh,trimesh.Trimesh) or len(mesh.faces)==0:
        raise ValueError('GLB contains no triangle mesh')
    uv=getattr(mesh.visual,'uv',None)
    if uv is None or len(uv)!=len(mesh.vertices):
        raise ValueError('GLB has no usable vertex UVs')
    if override:
        tex=Image.open(override).convert('RGBA')
    else:
        mat=getattr(mesh.visual,'material',None)
        tex=getattr(mat,'baseColorTexture',None)
        if tex is None:tex=getattr(mat,'image',None)
        if tex is None:raise ValueError('GLB has no embedded baseColorTexture; use --texture')
        tex=tex.convert('RGBA')
    return mesh,np.asarray(tex,dtype=np.uint8)


def face_colors(mesh):
    # Broad consistent region encoding, NOT original source part segmentation.
    verts=np.asarray(mesh.vertices,dtype=np.float32)[:,[0,2,1]]  # glTF Y-up -> Z-up
    centers=verts[np.asarray(mesh.faces)].mean(axis=1)
    low=verts.min(axis=0); high=verts.max(axis=0)
    long=(centers[:,0]-low[0])/max(.0001,high[0]-low[0])
    col=np.zeros((len(centers),4),dtype=np.uint8)
    col[:,:]=[233,193,73,255]
    col[centers[:,1]>0]=[83,199,108,255]
    col[long>.75]=[85,145,242,255]
    col[long<.20]=[230,73,72,255]
    # Mast, rig and sail separated by height, as an illustrative guide.
    col[centers[:,2] > low[2]+.72*(high[2]-low[2])]=[91,161,249,255]
    return col


def render_model(mesh,tex,size,scale,elevation):
    vs=np.asarray(mesh.vertices,dtype=np.float32)[:,[0,2,1]]  # glTF Y-up -> Z-up
    fs=np.asarray(mesh.faces,dtype=np.int32)
    vs=vs-((vs.min(axis=0)+vs.max(axis=0))/2)
    # World-scale stays identical across all headings; no per-view bounding-box fit.
    # Size scale based on full model longest dimension.
    unit=float(np.max(vs.max(axis=0)-vs.min(axis=0)))
    ratio=size*scale/max(unit,1.e-6)
    uv=np.asarray(mesh.visual.uv,dtype=np.float32)[fs]
    normals=np.asarray(mesh.face_normals,dtype=np.float32)[:,[0,2,1]]
    lightdir=np.array([-.30,.45,.85],dtype=np.float32);lightdir/=np.linalg.norm(lightdir)
    shade=np.clip(.77+.22*np.einsum('ij,j->i',normals,lightdir),.53,.99).astype(np.float32)
    diagcol=face_colors(mesh)
    cols={}
    outputs={'normal':{},'colored':{}}
    elev=math.radians(elevation)
    for d in ORDER:
        phi=math.radians(BOW_SCREEN_DEG[d])
        theta=math.atan2(math.sin(phi)/math.sin(elev),math.cos(phi))
        # Orthographic: x-axis of ship projects to angle phi, y-axis perpendicular.
        # camera elevation projection uses sin(elev) for ground and cos(elev) for height.
        qx=vs[:,0]*math.cos(theta)-vs[:,1]*math.sin(theta)
        qy=(vs[:,0]*math.sin(theta)+vs[:,1]*math.cos(theta))*math.sin(elev)-vs[:,2]*math.cos(elev)
        qz=(vs[:,0]*math.sin(theta)+vs[:,1]*math.cos(theta))*math.cos(elev)+vs[:,2]*math.sin(elev)
        proj=np.column_stack([qx*ratio+size/2,qy*ratio+size/2,qz]).astype(np.float32)
        tri=proj[fs]
        clearcol=np.zeros_like(diagcol)
        for mode,col in [('normal',clearcol),('colored',diagcol)]:
            sh=shade if mode=='normal' else (shade*.25+.75).astype(np.float32)
            image=Image.fromarray(_render(tri,uv,col,sh,tex,size),'RGBA')
            outputs[mode][d]=image
    return outputs


def make_sheet(frames,size,transparent):
    canvas=Image.new('RGBA',(1280,1280),(0,0,0,0) if transparent else (0,0,0,255))
    # Paint each fully independent, physically scaled view; verify no alpha overlaps.
    occupancy=np.zeros((1280,1280),np.uint8)
    overlaps=0
    for d in ORDER:
        img=frames[d]
        cx,cy=CENTERS[d];x=round(cx-size/2);y=round(cy-size/2)
        if min(x,y)<0 or x+size>1280 or y+size>1280:
            raise ValueError(f'View {d} extends off canvas; reduce --size')
        m=np.asarray(img.getchannel('A'))>8
        old=occupancy[y:y+size,x:x+size]
        overlaps+=int((old[m]>0).sum())
        old[m]=1
        canvas.alpha_composite(img,(x,y))
    if overlaps:raise ValueError(f'{overlaps} pixels overlap between views; reduce --size or --scale')
    return canvas


def main():
    p=argparse.ArgumentParser()
    p.add_argument('--glb',required=True,type=Path)
    p.add_argument('--outdir',required=True,type=Path)
    p.add_argument('--texture',type=Path,default=None)
    p.add_argument('--size',type=int,default=420)
    p.add_argument('--scale',type=float,default=.90,help='Fraction of normal reference scale; .90 leaves extra spacing')
    p.add_argument('--elevation',type=float,default=55)
    args=p.parse_args()
    if args.size>450 or args.size<128:raise ValueError('size must be 128..450 for 1280 radial sheet')
    args.outdir.mkdir(parents=True,exist_ok=True)
    mesh,tex=get_mesh_and_texture(args.glb,args.texture)
    frames=render_model(mesh,tex,args.size,args.scale,args.elevation)
    for mode in ('normal','colored'):
        for d,im in frames[mode].items():im.save(args.outdir/f'{mode}_{d}.png')
        for transparent in (False,True):
            suffix='_transparent' if transparent else ''
            make_sheet(frames[mode],args.size,transparent).save(args.outdir/f'recreated_8view_{mode}{suffix}.png')
    meta={'mesh_vertices':len(mesh.vertices),'mesh_faces':len(mesh.faces),'image_size':1280,
          'single_view_canvas':args.size,'reference_scale':args.scale,'elevation_degrees':args.elevation,
          'directions':list(ORDER),'source_glb':args.glb.name,'part_colors':'heuristic, not exact original mesh part IDs',
          'render_engine':'Numba software z-buffer with embedded glTF baseColorTexture'}
    (args.outdir/'render_report.json').write_text(json.dumps(meta,indent=2),encoding='utf-8')
    print(json.dumps(meta,ensure_ascii=False))

if __name__=='__main__':main()
