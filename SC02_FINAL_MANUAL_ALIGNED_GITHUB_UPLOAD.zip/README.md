# SC-02 Kül Dikişi — Final 8-Yön Manuel Hizalanmış Paket

Yön sırası:
N, NE, E, SE / S, SW, W, NW

İçerik:
- png/SC02_N.png ... SC02_NW.png: 1024×1024 şeffaf master yön kareleri
- SC02_base_atlas_4x2_1024.png: 4096×2048 master 4×2 atlas
- SC02_contactsheet_manual_aligned.png: görsel kalite kontrol
- SC02_rotation_manual_aligned.gif: dönüş önizlemesi
- SC02_manual_alignment.json: kullanıcı onaylı manuel X/Y/scale ayarları

Bu paket, N yönüne LUT eşleme + dünya-ölçek normalizasyonu + otomatik anchor
sonrasında kullanıcının mobil hizalama aracıyla verdiği manuel düzeltmeleri içerir.
