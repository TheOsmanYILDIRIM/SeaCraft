#!/usr/bin/env python3
"""
SeaCraft GLB -> 8-yon referans pano uretici.

Amac:
- Tek bir .glb modelden renksiz (normal) ve renkli geometri 8-yon pano uretmek.
- Kamera mantigi: ortografik benzeri, ~55 derece yukseklik, 45 derece yon araliklari.
- Cikti: tek tek yon PNG'leri ve birlesik 1280x1280 pano.

Notlar:
- Bu script saf-Python yazilim rasterizer kullanir; Blender/pyrender gerektirmez.
- Mevcut bundle'daki ciktilar bu scriptin hedef ciktilaridir.
- GLB'nin dokusu dosya icinde dogrudan okunamiyorsa --texture ile ayri PNG verilebilir.
"""
import argparse, math
from pathlib import Path
import numpy as np
from PIL import Image
import trimesh

DIRECTIONS=[('N',0),('NE',45),('E',90),('SE',135),('S',180),('SW',225),('W',270),('NW',315)]
SLOTS={'N':(640,210),'NE':(945,350),'E':(1030,640),'SE':(945,930),'S':(640,1070),'SW':(335,930),'W':(250,640),'NW':(335,350)}


def rot_x(deg):
    a=math.radians(deg); c,s=math.cos(a),math.sin(a)
    return np.array([[1,0,0],[0,c,-s],[0,s,c]],dtype=np.float32)

def rot_y(deg):
    a=math.radians(deg); c,s=math.cos(a),math.sin(a)
    return np.array([[c,0,s],[0,1,0],[-s,0,c]],dtype=np.float32)


def load_mesh(glb_path):
    scene=trimesh.load(glb_path, force='scene')
    mesh=scene.to_geometry()
    if not isinstance(mesh, trimesh.Trimesh):
        mesh=trimesh.util.concatenate(tuple(g for g in scene.geometry.values()))
    return mesh


def load_texture(texture_path):
    tex=Image.open(texture_path).convert('RGBA')
    return np.asarray(tex).astype(np.uint8)


def sample_texture(texture, uv):
    h,w,_=texture.shape
    u=np.clip(uv[:,0],0,1)
    v=np.clip(1.0-uv[:,1],0,1)
    x=np.clip((u*(w-1)).astype(int),0,w-1)
    y=np.clip((v*(h-1)).astype(int),0,h-1)
    return texture[y,x]


def classify_colors(local_vertices):
    # Basit heuristik: pruva mavi, kic kirmizi, sancak yesil, iskele sari
    mins=local_vertices.min(axis=0); maxs=local_vertices.max(axis=0)
    xnorm=(local_vertices[:,0]-mins[0]) / max(1e-6,(maxs[0]-mins[0]))
    ynorm=(local_vertices[:,1]-mins[1]) / max(1e-6,(maxs[1]-mins[1]))
    colors=np.zeros((len(local_vertices),4),dtype=np.uint8)
    bow=xnorm > 0.72
    stern=xnorm < 0.22
    mid=~(bow|stern)
    port=(ynorm >= 0.5) & mid
    star=(ynorm < 0.5) & mid
    colors[bow]=np.array([90,150,255,255],dtype=np.uint8)      # blue
    colors[stern]=np.array([235,70,70,255],dtype=np.uint8)     # red
    colors[port]=np.array([90,205,110,255],dtype=np.uint8)     # green
    colors[star]=np.array([240,195,75,255],dtype=np.uint8)     # yellow
    # herhangi biri bos kalirsa sari ver
    miss=np.where(colors[:,3]==0)[0]
    colors[miss]=np.array([240,195,75,255],dtype=np.uint8)
    return colors


def barycentric(p, a, b, c):
    v0=b-a; v1=c-a; v2=p-a
    d00=np.dot(v0,v0); d01=np.dot(v0,v1); d11=np.dot(v1,v1)
    d20=np.dot(v2,v0); d21=np.dot(v2,v1)
    denom=d00*d11-d01*d01
    if abs(denom) < 1e-8:
        return None
    v=(d11*d20-d01*d21)/denom
    w=(d00*d21-d01*d20)/denom
    u=1.0-v-w
    return u,v,w


def render_view(mesh, texture, mode='textured', heading_deg=0, elev_deg=55, size=512, pad=0.92):
    verts=np.asarray(mesh.vertices, dtype=np.float32)
    faces=np.asarray(mesh.faces, dtype=np.int32)
    uv=np.asarray(mesh.visual.uv, dtype=np.float32)

    # merkezle
    center=(verts.min(axis=0)+verts.max(axis=0))/2.0
    verts0=verts-center

    # kamera: once yatay dondurme sonra 55 derece egme
    R=rot_x(elev_deg) @ rot_y(-heading_deg)
    vv=verts0 @ R.T

    mins=vv[:,:2].min(axis=0); maxs=vv[:,:2].max(axis=0)
    span=max(maxs[0]-mins[0], maxs[1]-mins[1])
    scale=(size*pad)/max(span,1e-6)
    proj=np.empty((len(vv),3),dtype=np.float32)
    proj[:,0]=(vv[:,0]-((mins[0]+maxs[0])/2.0))*scale + size/2
    proj[:,1]=((maxs[1]+mins[1])/2.0 - vv[:,1])*scale + size/2
    proj[:,2]=vv[:,2]

    img=np.zeros((size,size,4),dtype=np.uint8)
    zbuf=np.full((size,size), -1e18, dtype=np.float32)

    color_table = classify_colors(verts0) if mode=='colored' else None

    for tri in faces:
        pts=proj[tri]
        xs=pts[:,0]; ys=pts[:,1]; zs=pts[:,2]
        minx=max(0,int(np.floor(xs.min()))); maxx=min(size-1,int(np.ceil(xs.max())))
        miny=max(0,int(np.floor(ys.min()))); maxy=min(size-1,int(np.ceil(ys.max())))
        if maxx < minx or maxy < miny:
            continue
        a=np.array([xs[0],ys[0]],dtype=np.float32); b=np.array([xs[1],ys[1]],dtype=np.float32); c=np.array([xs[2],ys[2]],dtype=np.float32)
        tri_uv=uv[tri]
        tri_col = color_table[tri] if color_table is not None else None
        denom=((b[1]-c[1])*(a[0]-c[0]) + (c[0]-b[0])*(a[1]-c[1]))
        if abs(denom) < 1e-8:
            continue
        for py in range(miny, maxy+1):
            for px in range(minx, maxx+1):
                p=np.array([px+0.5,py+0.5],dtype=np.float32)
                u,v,w=barycentric(p,a,b,c)
                if u is None or u < 0 or v < 0 or w < 0:
                    continue
                z=u*zs[0]+v*zs[1]+w*zs[2]
                if z <= zbuf[py,px]:
                    continue
                zbuf[py,px]=z
                if mode=='textured':
                    suv = u*tri_uv[0] + v*tri_uv[1] + w*tri_uv[2]
                    color=sample_texture(texture, np.array([suv]))[0]
                else:
                    color = np.clip(u*tri_col[0].astype(np.float32)+v*tri_col[1].astype(np.float32)+w*tri_col[2].astype(np.float32),0,255).astype(np.uint8)
                img[py,px]=color
    return Image.fromarray(img, 'RGBA')


def compose_sheet(individual, transparent=False):
    bg=(0,0,0,0) if transparent else (0,0,0,255)
    canvas=Image.new('RGBA',(1280,1280),bg)
    for key,_ in DIRECTIONS:
        im=individual[key]
        cx,cy=SLOTS[key]
        x=int(cx-im.width/2)
        y=int(cy-im.height/2)
        canvas.alpha_composite(im,(x,y))
    return canvas


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--glb', required=True)
    ap.add_argument('--texture', required=True)
    ap.add_argument('--outdir', required=True)
    ap.add_argument('--size', type=int, default=512)
    args=ap.parse_args()
    out=Path(args.outdir); out.mkdir(parents=True, exist_ok=True)
    mesh=load_mesh(args.glb)
    texture=load_texture(args.texture)
    normal, colored = {}, {}
    for key,deg in DIRECTIONS:
        normal[key]=render_view(mesh, texture, mode='textured', heading_deg=deg, size=args.size)
        colored[key]=render_view(mesh, texture, mode='colored', heading_deg=deg, size=args.size)
        normal[key].save(out/f'normal_{key}.png')
        colored[key].save(out/f'colored_{key}.png')
    compose_sheet(normal).save(out/'recreated_8view_normal.png')
    compose_sheet(colored).save(out/'recreated_8view_colored.png')
    compose_sheet(normal, transparent=True).save(out/'recreated_8view_normal_transparent.png')
    compose_sheet(colored, transparent=True).save(out/'recreated_8view_colored_transparent.png')
    print('done:', out)

if __name__=='__main__':
    main()
