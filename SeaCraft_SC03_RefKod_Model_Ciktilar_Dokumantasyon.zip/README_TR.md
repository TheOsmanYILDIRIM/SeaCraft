# SeaCraft — GLB referans üretimi + gemi üretim pipeline notları

Bu paket üç şeyi birlikte toplar:

1. **En son kullanılan 3D model** (`model/sample_2026-11-22T165909.224.glb`)
2. **Bu modelden 8 yön referans üretme kodu** (`code/generate_glb_8view_refs.py`)
3. **Üretilen renkli / renksiz referans panoları ve ilgili notlar**

## Pakette ne var?

### Model
- `model/sample_2026-11-22T165909.224.glb`

### Kod
- `code/generate_glb_8view_refs.py`
  - GLB modeli yükler.
  - 55° eğimli, ortografik benzeri görünüm kullanır.
  - 8 yön (N, NE, E, SE, S, SW, W, NW) render eder.
  - İki pano üretir:
    - `normal` = dokulu / renksiz referans pano
    - `colored` = parça-klasifikasyon renkli geometri pano

### Çıktılar
- `outputs/recreated_8view_normal.png`
- `outputs/recreated_8view_colored.png`
- `outputs/recreated_8view_normal_scaled90.png`
- `outputs/recreated_8view_colored_scaled90.png`
- `outputs/reference_comparison.png`
- `outputs/original_8view_normal.png`
- `outputs/original_8view_colored.png`
- `outputs/glb_basecolor.png`

### Yelken kütüphanesi örnekleri
- `sail_refs/SQ-1_single_square_sail.png`
- `sail_refs/SQ-2_double_square_sail.png`
- `sail_refs/GF-1_gaff_plus_jib_combo.png`
- `sail_refs/JB-1_jib.png`
- `sail_refs/LT-1_lateen.png`

## Neden iki farklı 8 yön referansı var?

### 1) Renksiz / normal 8 yön pano
Amaç:
- kamera standardını kilitlemek
- radial yerleşimi sabitlemek
- geminin 8 yönde merkez etrafında nasıl dizileceğini göstermek
- nihai gemi üretim promptunda "kamera / framing / ortografik yükseklik" referansı olmak

### 2) Renkli 8 yön pano
Amaç:
- aynı fiziksel gövdenin 8 yönde nasıl döndüğünü anlatmak
- pruva / kıç / sancak / iskele / üst yapı ilişkisini sabitlemek
- modelin her yönde farklı gemiler üretmesini engellemek
- yapısal süreklilik için teşhis amaçlı rehber olmak

Bu renkler **nihai gemiye aktarılmaz**. Sadece geometri sürekliliğini anlatır.

## %10 küçültülmüş pano neden üretildi?
Bazı denemelerde 8 yön gemiler birbirine fazla yaklaşıp temas etti. Bu yüzden aynı 3D referans panolarının %10 küçültülmüş sürümleri de üretildi. Böylece nihai üretim promptunda daha güvenli boşluk bırakılabiliyor.

## Şu anki standart arma / yelken kütüphanesi mantığı

Artık her gemi için birleşik bir arma referansı üretmek yerine, modüler arma kütüphanesi yaklaşımı kullanılıyor.

Temel modüller:
- **SQ-1** = tek kare yelken
- **SQ-2** = çift kare yelken
- **GF-1** = gaff / fore-and-aft ana yelken tipi
- **JB-1** = jib / flok
- **LT-1** = lateen / latin kıç yelkeni

Yöntem:
1. Önce bu standart modüller üretilir.
2. Sonra her gemi için hangi direkte hangi modül kullanılacak belirlenir.
3. Nihai gemi promptunda bu modül listesi referans olarak verilir.

## SC-03 için hangi modüller kullanıldı?
SC-03 (Tuz Ambarı) için kullanılan kombinasyon:
- foremast = `SQ-1`
- mainmast = `SQ-1`
- mizzenmast = `LT-1`

Yani doğrudan "tek birleşik arma referansı" yerine modüler çağırım yapıldı.
