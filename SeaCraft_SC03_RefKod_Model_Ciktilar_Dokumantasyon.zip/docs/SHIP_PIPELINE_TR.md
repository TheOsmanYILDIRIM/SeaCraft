# Sıfırdan gemi üretip GitHub yükleme ZIP'ine kadar tam pipeline

Bu belge, şu anda kullanılan gerçek süreci özetler.

## A. Hazırlık
1. Gemi kimliği tanımlanır.
   - örn. SC-03 = geniş gövdeli ticaret fluyt'u
2. Gerekli arma modülleri belirlenir.
   - örn. SC-03 = SQ-1 + SQ-1 + LT-1
3. Ortak referanslar hazırlanır:
   - renksiz 8 yön pano
   - renkli 8 yön geometri pano
   - texture atlas
   - arma / yelken modülleri

## B. İlk büyük üretim (tek karede 8 yön)
AI'ye doğrudan tek bir 8 yön radial pano ürettirilir.
Bu prompt içinde ayrı ayrı şu roller tanımlanır:
- 8 yön kamera referansı
- renkli geometri süreklilik referansı
- texture atlas malzeme rehberi
- yelken modülü referansları
- geminin kanonik tasarım açıklaması

## C. Çıktı kontrolü
Kontrol edilenler:
- 8 yön tam mı?
- gemiler birbirine temas ediyor mu?
- bütün yönlerde aynı fiziksel gemi mi dönüyor?
- arma sürekliliği korunmuş mu?
- yelkenler karışmış mı?
- radial düzen doğru mu?

Temas varsa ya prompt güncellenir ya da 3D referans panoları küçültülür.

## D. 8 yönü ayırma
Tek karede gelen pano sekiz bağımsız PNG'ye ayrılır.
Bu aşamada:
- alfa bileşeni analizi yapılır
- komşu gemi parçaları varsa temizlenir
- her yön ayrı dosya olur

## E. ShowLook v3 / renk standardizasyonu
Ham yön PNG'leri oyun stiline yaklaştırılır.
Amaç:
- ton birliği
- kontrast dengesi
- aynı geminin tüm yönlerde benzer görünmesi
- çok soluk / çok sıcak / çok yapay alanları dizginlemek

## F. Ön atlas ve manuel hizalama HTML'i
Sekiz yön PNG'ler hizalama öncesi bir 4x2 atlas halinde de hazırlanır.
Ayrıca tek HTML dosyası içinde manuel hizalama aracı üretilir.
Kullanıcı burada:
- x/y konum kaydırır
- gerekirse ölçek uygular
- JSON olarak export eder

## G. JSON'u uygula
Dönen JSON ile nihai 224x224 oyun hücreleri üretilir.
Bu hücreler:
- şeffaf arka planlıdır
- merkezleme sorunları düzeltilmiştir
- oyuna uygun boşluk bırakır

## H. Dönüş GIF'leri
Kontrol için şu tip GIF'ler üretilebilir:
- sade 8 yön dönüş
- 10° çift taraflı geçişli dönüş
- 7 FPS inceleme sürümü
- 21 FPS oyun hissi sürümü

Bu GIF'ler oyundaki gerçek hisse yaklaşmak ve hizalamayı test etmek için kullanılır.

## I. Nihai GitHub yükleme paketi
Son ZIP genelde şunları içerir:
- 8 adet nihai PNG
- 4x2 atlas PNG
- 21 FPS kontrol GIF'i
- orijinal radial üretim PNG'si
- manifest / not dosyası
- bazen hizalama JSON'u veya kaynak yardımcı dosya

## J. Neden bu kadar fazla ara adım var?
Çünkü tek seferde gelen 8 yönlü üretim genelde:
- temas
- tutarsız yönler
- yanlış yelkenler
- merkezleme hataları
- renk kaymaları
üretebiliyor.

Bu pipeline bunları kademeli temizlemek için var.
