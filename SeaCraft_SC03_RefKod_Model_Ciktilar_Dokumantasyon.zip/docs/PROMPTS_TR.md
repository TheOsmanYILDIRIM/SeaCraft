# Kullanılan güncel promptlar

## 1) LT-1 — Lateen sail referans promptu

Create a clean, professional 3D reference sheet of a SINGLE LATEEN SAIL RIG MODULE (LT-1) in a STRICT 1:1 SQUARE FORMAT.

This is a reusable modular sail reference for SeaCraft, NOT a complete ship or a final textured game asset.

RIG GEOMETRY
- Exactly ONE vertical mast.
- Exactly ONE long diagonal lateen yard crossing the mast at an oblique angle.
- Exactly ONE triangular lateen sail suspended from the diagonal yard.
- The sail extends predominantly aft of the mast.
- The upper edge follows the diagonal yard.
- The lower edge is free, with a gentle natural fabric curve.
- The sail has subtle wind-filled curvature and realistic fabric tension.
- Include only minimal functional attachments.

The construction must clearly read as a historical lateen rig, NOT a gaff, jib or square sail.

FOUR ORTHOGRAPHIC VIEWS — 2×2 GRID
- Top-left: front view.
- Top-right: back view.
- Bottom-left: side view.
- Bottom-right: three-quarter isometric view at 55° elevation.

All four views must show the EXACT SAME physical rig assembly. Only the camera direction changes.

VISUAL STYLE
- Minimal professional 3D clay render.
- Matte light-grey sailcloth.
- Dark charcoal-grey mast and diagonal yard.
- Soft neutral studio lighting.
- No photographic textures, stitching, weathering or material decorations.
- Clearly defined geometric silhouettes.

IMPORTANT RESTRICTIONS
- No hull or deck.
- No extra sails or masts.
- No square yards, horizontal booms or gaff sails.
- No complex rope webs or side shrouds.
- No ocean, sky, background scenery, labels or UI.
- No exaggerated fantasy shapes.

Keep the module clean and structurally understandable. Its proportions may be adapted later for different ship classes.

OUTPUT
One STRICT 1:1 SQUARE image containing four consistent orthographic views of the same LT-1 lateen sail rig, arranged in a clean 2×2 grid.

---

## 2) SC-03 — nihai 8 yön radial üretim promptu

Referans sırası:
1. renksiz 8 yön 3D kamera referansı
2. renkli 8 yön geometri referansı
3. texture atlas
4. SQ-1 tek kare yelken referansı
5. LT-1 lateen yelken referansı

Create ONE complete EIGHT-DIRECTION RADIAL SHIP SPRITE SHEET of SC-03 “Tuz Ambarı” in a STRICT 1:1 SQUARE FORMAT.

This is a premium production-quality 2.5D game asset for SeaCraft, a dark, atmospheric nautical game with realistic materials and carefully stylized ship silhouettes.

Depict exactly EIGHT views of ONE physically identical Dutch fluyt merchant ship.

The five attached images have DIFFERENT reference roles. Follow their roles precisely.

REFERENCE 1 — EIGHT-DIRECTION CAMERA AND RADIAL LAYOUT
Use this reference for:
- The exact circular eight-view arrangement.
- Bow-inward orientation toward the empty center.
- True orthographic projection.
- Fixed camera elevation of approximately 55°.
- Camera distance, viewing directions and framing.
- Consistent object scale across all eight views.
Do NOT copy the example ship's hull, rigging or decorations.

REFERENCE 2 — COLORED EIGHT-DIRECTION GEOMETRY GUIDE
Use this reference to understand how the SAME rigid physical vessel appears from eight directions.
Follow its geometric continuity logic:
- Bow position and orientation.
- Stern position and orientation.
- Port and starboard identities.
- Deck and hull volumes.
- Structural landmarks that rotate consistently.
- Natural occlusion across viewing angles.
The reference's diagnostic colors are NOT part of the final design.
Do NOT copy its actual hull architecture.
SC-03 must retain its own broad, deep Dutch fluyt geometry.

REFERENCE 3 — SEA CRAFT MATERIAL / TEXTURE ATLAS
Treat the supplied texture atlas as the authoritative source for the game's material families.
Do not invent an unrelated texture style.
Select and adapt materials from their corresponding atlas samples.
WOOD:
Use the atlas's weathered oak and dark timber examples as the primary source.
For SC-03, shift the selected wood toward salt-weathered brown oak, retaining the atlas's plank grain, roughness, wear and realistic surface detail.
The hull should be damp and aged, but slightly warmer and browner than SC-02's almost black wet oak.
Preserve visible plank construction, heavier structural beams and natural grain direction.
Do not introduce excessively bright, orange or polished wood.
SAILCLOTH:
Use the atlas's aged heavy-canvas material family.
Adapt the material toward dirty bone-beige linen, with muted grey-brown weathering.
Preserve the reference fabric's weight, natural folds, seam character and realistic light response.
The sails must not be bright white, golden, translucent or smooth plastic.
ROPE:
Use the atlas's aged fibrous rope examples.
Keep the rope dark, weathered and damp rather than freshly manufactured.
METAL:
Use the atlas's oxidized iron and forged-metal surfaces for fittings, hinges, rings and structural fasteners.
Keep metal matte, worn and restrained.
CARGO COVERINGS:
Use dark oilcloth-like surfaces consistent with the atlas's weathered maritime material language.
Avoid introducing unrelated synthetic materials.
Apply material variation according to function, not random decorative noise.

REFERENCE 4 — SQ-1 SINGLE SQUARE SAIL MODULE
This reference defines the geometric identity of ONE square-sail rig module.
Use it TWICE:
- One SQ-1 module on the FOREMAST.
- One SQ-1 module on the MAINMAST.
Each mast carries exactly ONE broad square sail.
Adapt both modules for a compact cargo fluyt:
- Shorter, sturdier masts.
- Relatively broad square sails.
- Heavy canvas with gentle wind-filled curvature.
- Practical, workmanlike proportions.
The two modules may differ slightly in scale to fit their mast positions, but their construction must remain consistent with Reference 4.
Do not add second or third tiers of square sails.

REFERENCE 5 — LT-1 LATEEN SAIL MODULE
This reference defines the triangular lateen rig assembly.
Use it exactly ONCE on the aft MIZZENMAST.
Preserve:
- One short mast.
- One long diagonally inclined lateen yard.
- One triangular sail suspended from that yard.
- A gently curved free lower sail edge.
- The same structural identity shown in Reference 5.
Scale this module down to fit the compact aft rig.
It must remain clearly distinguishable from a gaff sail, jib or square sail.
Do not invent additional sails.

SHIP IDENTITY — SC-03 “TUZ AMBARI”
SC-03 is a compact, heavily built Dutch fluyt designed primarily for merchant cargo transport and smuggling.
Its silhouette must be fundamentally different from a military brig, frigate or galleon.
HULL GEOMETRY:
- Hull length-to-beam ratio approximately 3.0:1.
- Broad, deep cargo-carrying belly.
- Maximum beam concentrated around the lower and middle hull.
- Upper sides curve noticeably inward above the wide lower hull.
- Rounded bow rather than a sharp wedge-shaped warship prow.
- Distinctive pear-shaped rounded stern.
- Compact, heavy merchant construction.
- No tall sterncastle.
- No aggressive military ram or elaborate figurehead.
The hull should look volumetrically broad and cargo-capable, not simply like an elongated narrow boat.
DECK AND CARGO:
- One visible working deck with a cargo hold beneath.
- One prominent central rectangular cargo hatch.
- Clearly constructed hatch framing.
- A small amount of functional cargo equipment.
- Modest ropes, barrels and dark covered cargo where appropriate.
- Keep the central hatch recognizable across viewing angles.
- Avoid clutter that obscures the hull or sail arrangement.
WEAPONS:
- No cannon batteries.
- No enclosed gunports.
- No rows of broadside cannons.
- No military gun deck.

EXACT RIGGING COMPOSITION
Exactly THREE SHORT MASTS arranged longitudinally:
FOREMAST: One SQ-1 broad square sail.
MAINMAST: One SQ-1 broad square sail.
AFT MIZZENMAST: One smaller LT-1 triangular lateen sail.
TOTAL: THREE masts. THREE sails.
The square sails must be clearly separated in physical space.
The lateen sail must remain visibly attached to the aft mast and must not merge into the neighboring square sail.
All masts must occupy fixed positions on the same continuous deck across all eight views.
The rigging should feel functional, restrained and physically believable.
Avoid dense rope forests or decorative complexity.

SC-03 IDENTITY DETAILS
Include restrained merchant-specific identifiers:
- A simple dirty bone-colored pennant near the aft mizzen mast.
- Two subtle cargo-hold markings.
- One small weathered fitting at the bow.
- Minimal ornamentation.
- Evidence of salt exposure and maritime wear.
- A few compact functional deck fittings.
Do not add elaborate sculpted figureheads, giant emblems or fantasy decorations.

SEA CRAFT VISUAL STYLE — CRITICAL
Match SeaCraft's established visual language.
Premium dark nautical stylized realism with high-quality realistic material rendering.
This is NOT cartoon art, pixel art or a painted illustration.
The ship should look like an expensive, carefully art-directed 3D game asset rendered into an orthographic 2.5D sprite.
Visual characteristics:
- Dark cinematic maritime atmosphere.
- Physically believable construction.
- Strong readable hull and sail silhouettes.
- Realistic timber, canvas, rope and oxidized-metal materials derived from Reference 3.
- Deep but readable shadows.
- Controlled wet-surface highlights.
- Rich material detail without excessive sharpness.
- Subtle salt residue, grime and wear only where structurally plausible.
- No artificial black outlines.
- No plastic-like surfaces.
- No exaggerated fantasy colors.
- No oversaturated highlights.
- No excessive procedural grunge.
Lighting must come from one consistent upper-left, cool, broad light source.
Use soft shadow transitions and restrained physically plausible reflections.
Preserve readable differences between dark hull timber, aged sailcloth, iron fittings and deck structures.
The ship should feel weathered, functional, heavy and historically grounded, with only a subtle unsettling SeaCraft atmosphere.
The dark atmosphere belongs to the vessel's materials and lighting, NOT to added fog or scenery.

EIGHT-DIRECTION RADIAL ARRANGEMENT
Render exactly eight ship views in this circular arrangement:
N — top
NE — upper-right
E — right
SE — lower-right
S — bottom
SW — lower-left
W — left
NW — upper-left
All bows point INWARD toward the empty center, matching Reference 1.
Each view must represent the same SC-03 physical vessel rotated into the corresponding world heading.
Maintain the reference's radial layout without copying the reference vessel's actual design.

CAMERA RULES
TRUE ORTHOGRAPHIC / PARALLEL PROJECTION.
Fixed camera elevation approximately 55° above horizontal.
Zero camera roll.
Consistent camera framing.
Identical world-space vessel scale across all views.
Exactly 45° directional increments.
No perspective distortion.
No arbitrary camera-height changes.
No mirrored or duplicated ship views.
Preserve genuine port/starboard differences and natural occlusion.

PHYSICAL CONSISTENCY
Across all eight views, maintain exactly:
- The same broad 3:1 hull.
- The same rounded bow and pear-shaped stern.
- The same cargo hatch.
- The same three mast positions.
- The same two SQ-1 square-sail assemblies.
- The same single LT-1 lateen assembly.
- The same sail proportions.
- The same cargo equipment placement.
- The same pennant and markings.
- The same plank and material identity.
Do not add or remove structures depending on camera angle.
Only visibility and natural projection may change.

COMPOSITION AND OUTPUT
Arrange the eight complete vessels evenly around a clear central empty region.
Every ship must be fully visible.
No clipping of bows, sterns, mast tips, spars, sails, flags or other structural parts.
All eight views must have consistent visual quality, material identity and lighting.
Use a true transparent RGBA background if supported.
Otherwise use a perfectly uniform dark navy-grey background that is easy to remove cleanly.
STRICT EXCLUSIONS:
No ocean.
No water surface.
No foam.
No wake.
No splashes.
No sky.
No fog.
No smoke.
No external cast shadow.
No text.
No direction labels.
No compass graphics.
No interface.
No borders.
No extra vessels.
No diagnostic segmentation colors.
FINAL VALIDATION
Before finalizing, visually verify:
1. Exactly eight views.
2. Exactly one consistent Dutch fluyt vessel.
3. Exactly three masts per view.
4. Exactly two broad square sails and one aft lateen sail per view.
5. Correct radial arrangement with all bows pointing inward.
6. Strong broad cargo-hull silhouette.
7. Texture atlas material language preserved.
8. Consistent physical geometry and camera setup.
9. No clipping or overlapping neighboring vessels.
The final image must communicate a heavy, compact, historically inspired merchant fluyt with unmistakable cargo capacity and a practical three-mast rig.
ABSOLUTE OUTPUT REQUIREMENT:
ONE SINGLE STRICT 1:1 SQUARE IMAGE.
WIDTH AND HEIGHT MUST BE IDENTICAL.
ALL EIGHT VIEWS MUST FIT COMPLETELY INSIDE THE SQUARE.
