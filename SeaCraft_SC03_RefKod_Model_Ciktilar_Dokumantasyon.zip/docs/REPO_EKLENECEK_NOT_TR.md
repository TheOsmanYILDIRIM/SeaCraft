# Repo'ya eklenecek kısa not önerisi

SC-02 / SC-03 ve sonraki gemiler için 8 yönlü üretimlerde, kamera ve geometri sürekliliğini korumak amacıyla GLB modelden yeniden üretilen iki ortak referans pano kullanılıyor:

- `recreated_8view_normal.png` = renksiz / dokulu 8 yön kamera ve radial yerleşim referansı
- `recreated_8view_colored.png` = renkli geometri süreklilik referansı

Bu iki pano tek başına nihai gemi tasarımı değildir; yalnızca şu amaçlara hizmet eder:
1. 55° ortografik benzeri kamera standardını sabitlemek
2. 8 yön radial düzenini sabitlemek
3. aynı fiziksel gövdenin 8 yönde tutarlı dönmesini anlatmak

Arma üretiminde birleşik gemi-özel referans yerine modüler yelken kütüphanesi yaklaşımı kullanılmaktadır.
Temel modüller:
- SQ-1, SQ-2, GF-1, JB-1, LT-1

Her gemi için önce gereken modül kombinasyonu belirlenir, sonra nihai 8 yönlü gemi promptuna bu referanslar ayrı ayrı eklenir.
